
var assert = require('assert');
var webdriver = require('selenium-webdriver');
var test = require('selenium-webdriver/testing');
var By = webdriver.By;

/*
 * Use PhantomJS as Browser
 */

var phantomjs_exe = require('phantomjs-prebuilt').path;
var customPhantom = webdriver.Capabilities.phantomjs();
customPhantom.set("phantomjs.binary.path", phantomjs_exe);
var browser = new webdriver.Builder()
        .withCapabilities(customPhantom).build();
/*
 * Execute Tests
 */

const ServerAddress = 'http://127.0.0.1:3000';


test.describe('opettajat_kyselyt:', function () {

// 170907/TiM
//    test.it('opettajat-sivulla on odotettu sisältö', () => {
   test.it('opettajat-sivulla on odotettu sisältö (mm. opettajat aakkosjärjestyksessä)', () => {

      browser.get(`${ServerAddress}/opettajat`).then(() => {

         const ExpectedH2Content = 'Opettajat';

         browser.findElement(By.css('h2')).getText().then((elementText) => {
            assert.ok(elementText.includes(ExpectedH2Content),
                    `h2-elementin sisältö: "${elementText}"; odotettu sisältö: "${ExpectedH2Content}"`);
         });


         const ExpectedLength = 6;
         const ExpectedA0Content = 'Ahtola';
         const ExpectedA1Content = 'Jukola';
         const ExpectedA3Content = 'Mikama';

         browser.findElements(By.css('li a')).then((elements) => {

            assert.equal(elements.length, ExpectedLength,
                    `"li a"-elementien lukumäärä: "${elements.length}"; odotettu määrä: "${ExpectedLength}"`);

            elements[0].getText().then((elementText) => {
               assert.ok(elementText.includes(ExpectedA0Content),
                       `1. a-elementin sisältö: "${elementText}"; odotettu sisältö: "${ExpectedA0Content}"`);
            });

            elements[1].getText().then((elementText) => {
               assert.ok(elementText.includes(ExpectedA1Content),
                       `2. a-elementin sisältö: "${elementText}"; odotettu sisältö: "${ExpectedA1Content}"`);
            });

            elements[3].getText().then((elementText) => {
               assert.ok(elementText.includes(ExpectedA3Content),
                       `4. a-elementin sisältö: "${elementText}"; odotettu sisältö: "${ExpectedA3Content}"`);
            });

         });

      });

   });// test.it


   test.it('opettajat-sivun linkin klikkaus vie opettaja-sivulle', () => {

      browser.get(`${ServerAddress}/opettajat`).then(() => {

// 170907/TiM
//            browser.findElements(By.css('li a')).then((elements) => {
         browser.findElements(By.partialLinkText('Jukola')).then((elements) => {

// 170907/TiM
//                elements[1].click().then(() => {
            elements[0].click().then(() => {

               const ExpectedH2Content = 'Opettaja';
               const ExpectedInstructor = 'Jukola';

               browser.findElement(By.css('h2')).getText().then((elementText) => {
                  assert.equal(elementText, ExpectedH2Content,
                          `sivun otsikon (h2-elementti) sisältö: "${elementText}"; odotettu sisältö: "${ExpectedH2Content}"`);
               });

               browser.findElement(By.css('body')).getText().then((elementText) => {
                  assert.ok(elementText.includes(ExpectedInstructor),
                          `sivulta pitäisi (sisältö: "${elementText}") pitäisi löytyä teksti: "${ExpectedInstructor}"`);
               });
            });
         });
      });
   });// test.it


   test.it('opettaja-sivulla on odotettu sisältö', () => {

// 170907/TiM
//        const InstructorId = '5';

      const ExpectedH2Content = 'Opettaja';
      const ExpectedFirstname = 'Santtu';
      const ExpectedLastname = 'Mikama';


// 170907/TiM
// - opettaja-sivulle opettajat-sivun kautta
//        browser.get(`${ServerAddress}/opettajat/${InstructorId}`).then(() => {
      browser.get(`${ServerAddress}/opettajat`).then(() => {
         browser.findElements(By.partialLinkText('Mikama')).then((elements) => {
            elements[0].click().then(() => {


               browser.findElement(By.css('h2')).getText().then((elementText) => {
                  assert.equal(elementText, ExpectedH2Content,
                          `sivun otsikon (h2-elementti) sisältö: "${elementText}"; odotettu sisältö: "${ExpectedH2Content}"`);
               });

               browser.findElement(By.css('body')).getText().then((elementText) => {

                  assert.ok(elementText.includes(ExpectedFirstname),
                          `sivulta pitäisi (sisältö: "${elementText}") pitäisi löytyä teksti: "${ExpectedFirstname}"`);

                  assert.ok(elementText.includes(ExpectedLastname),
                          `sivulta pitäisi (sisältö: "${elementText}") pitäisi löytyä teksti: "${ExpectedLastname}"`);

               });

               const ExpectedCoursesLength = 4;
               const ExpectedA0Content = 'Mobiiliohjelmointi';
               const ExpectedA2Content = 'Olio-ohjelmointi';

               browser.findElements(By.css('li a')).then((elements) => {

                  assert.equal(elements.length, ExpectedCoursesLength,
                          `"li a"-elementien lukumäärä: "${elements.length}"; odotettu määrä: "${ExpectedCoursesLength}"`);


                  elements[0].getText().then((elementText) => {
                     assert.ok(elementText.includes(ExpectedA0Content),
                             `1. a-elementin sisältö: "${elementText}"; odotettu sisältö: "${ExpectedA0Content}"`);
                  });

                  elements[2].getText().then((elementText) => {
                     assert.ok(elementText.includes(ExpectedA2Content),
                             `3. a-elementin sisältö: "${elementText}"; odotettu sisältö: "${ExpectedA2Content}"`);
                  });

               });


            });
         });
      });
   });// test.it



   test.it('opettaja-sivun linkin klikkaus vie kurssi-sivulle', () => {

// 170907/TiM
//      const InstructorId = '5';

      const ExpectedH2Content = 'Kurssi';
      const ExpectedCoursename = 'Mobiiliohjelmointi';


// 170907/TiM
// - opettaja-sivulle opettajat-sivun kautta
//      browser.get(`${ServerAddress}/opettajat/${InstructorId}`).then(() => {
      browser.get(`${ServerAddress}/opettajat`).then(() => {
         browser.findElements(By.partialLinkText('Mikama')).then((elements) => {
            elements[0].click().then(() => {


               browser.findElement(By.css('li a')).click().then(() => {

                  browser.findElement(By.css('h2')).getText().then((elementText) => {
                     assert.equal(elementText, ExpectedH2Content,
                             `sivun otsikon (h2-elementti) sisältö: "${elementText}"; odotettu sisältö: "${ExpectedH2Content}"`);
                  });

                  browser.findElement(By.css('body')).getText().then((elementText) => {

                     assert.ok(elementText.includes(ExpectedCoursename),
                             `sivulta pitäisi (sisältö: "${elementText}") pitäisi löytyä teksti: "${ExpectedCoursename}"`);
                  });

               });
            });
         });
      });

   });// test.it

});

