
console.log('** Kurssi **');

const db = require('../config/db_connection');
const Opettaja = require('./Opettaja');

const DataTypes = db.Sequelize.DataTypes;

const Kurssi = db.define('kurssi', {
   id: {
      type: DataTypes.INTEGER,
      autoIncrement: true,
      primaryKey: true
   },
   tunnus: DataTypes.STRING,
   nimi: DataTypes.STRING,
   laajuus: DataTypes.STRING
});

Kurssi.belongsTo(Opettaja);
Opettaja.hasMany(Kurssi);

db.sync();

module.exports = Kurssi;

