
console.log('** Opettaja **');

const db = require('../config/db_connection');
const DataTypes = db.Sequelize.DataTypes;

const Opettaja = db.define('opettaja', {
   id: {
      type: DataTypes.INTEGER,
      autoIncrement: true,
      primaryKey: true
   },
   etunimi: DataTypes.STRING,
   sukunimi: DataTypes.STRING
});

module.exports = Opettaja;

