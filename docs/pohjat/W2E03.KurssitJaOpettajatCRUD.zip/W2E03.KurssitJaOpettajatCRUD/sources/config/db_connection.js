
console.log('** db_connection **');

const Sequelize = require('sequelize');

const db = new Sequelize('koulu', '', '', {
   dialect: 'sqlite',
   storage: 'database/koulu.sqlite',
   define: {
      timestamps: false
   }
});

module.exports = db;

