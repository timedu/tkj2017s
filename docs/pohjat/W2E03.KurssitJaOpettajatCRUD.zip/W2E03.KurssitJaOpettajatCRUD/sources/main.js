
console.log('** db_main **');

/* global __dirname */


// Express-sovelluskehyksen käyttöönotto
const app = require('express')();


// Lomakkeilta vastaanotettavan datan jäsennys
app.use(require('body-parser').urlencoded({extended: false}));


// Sivupohjien käyttöönotto ja -asetukset
const handlebars = require('express-handlebars');
app.engine('.hbs', handlebars({
    defaultLayout: 'main',
    extname: '.hbs',
    layoutsDir: 'sources/views/layouts/'
}));
app.set('view engine', '.hbs');
app.set('views', __dirname + '/views');


// Tietokannan alustaminen
require('./config/db_create');


// Kontrollerit

require('./controllers/kurssiControllerCUD')(app);
require('./controllers/opettajaControllerCUD')(app);

require('./controllers/kurssiController')(app);
require('./controllers/opettajaController')(app);


// Sovelluksen käynnistys
const hostname = '127.0.0.1', port = 3000;
app.listen(port, hostname, function(){
    console.log(`Server running at http://${hostname}:${port}/`);
});


