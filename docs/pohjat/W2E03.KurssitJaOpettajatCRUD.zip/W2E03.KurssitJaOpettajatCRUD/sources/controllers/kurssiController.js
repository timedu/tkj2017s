
console.log('** kurssiController **');

// TKJ, Tehtävä 2.2

// Nimi: 
// OppNro: 


const Kurssi = require('../models/Kurssi');
const Opettaja = require('../models/Opettaja');


module.exports = function (app) {

    app.get('/', function (req, res) {
        res.redirect('/kurssit');
    });

    app.get('/kurssit', function (req, res) {

         res.send(req.url);
    });

    app.get('/kurssit/:id', function (req, res) {

        Kurssi.findById(req.params.id,{
            include: [Opettaja]
        }).then(function (kurssi) {
            res.render('kurssi_detail', {
                kurssi: kurssi
            });
        });
    });
};

