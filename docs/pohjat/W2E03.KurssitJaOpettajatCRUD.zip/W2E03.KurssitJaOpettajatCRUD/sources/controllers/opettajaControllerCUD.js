
console.log('** opettajaControllerCUD **');

// TKJ, Tehtävä 2.3

// Nimi: 
// OppNro: 

const Opettaja = require('../models/Opettaja');

module.exports = function (app) {

   /*
    * Create
    */

   app.get('/opettajat/create', function (req, res) {

       res.send(req.url);
   });

   app.post('/opettajat/create', function (req, res) {

       res.redirect('/opettajat/create');
   });

   /*
    * Update
    */

   app.get('/opettajat/:id/update', function (req, res) {

       res.send(req.url);
   });

   app.post('/opettajat/update', function (req, res)
   {
       res.redirect('/opettajat/1/update');
   });

   /*
    * Delete
    */

   app.get('/opettajat/:id/delete', function (req, res) {

       res.send(req.url);      
   });

   app.post('/opettajat/delete', function (req, res)
   {
       res.redirect('/opettajat/1/delete');
   });

};

