
console.log('** opettajaControllerCUD **');

// TKJ, Tehtävä 2.3

// Nimi: 
// OppNro: 

const Opettaja = require('../models/Opettaja');

module.exports = function (app) {

   /*
    * ----------------------------------------------------------------------
    * Create: uuden opettajan lisäys tietokantaan
    * ----------------------------------------------------------------------
    */

   /*
    * Lomake kurssin tietojan syöttöä varten
    */
   app.get('/opettajat/create', function (req, res) {

      /*
       * Hahmonnetaan näkymä 'opettaja_create', joka sisältää lomakkeen 
       * opettajan tietojen syöttämistä varten. 
       */

      res.render('opettaja_create');
   });

   /*
    * Uuden opettajan talletus tietokantaan
    */
   app.post('/opettajat/create', function (req, res) {

      /*
       * Jos käyttäjä klikkaa Lisää Opettaja -sivulla 'Peruuta' -painiketta,
       * ohjataan käsittely Opettajat -sivulle ja keskeytetään tämän funktion
       * toiminta.
       * 
       * Peruuta-painikkeen name-attribuutin arvo lomakkeessa on '_cancel'.
       * Lomakkeen kaikkien input elementtien vastineet löytyvät req-objektin
       * body-ominaisuudesta. Siten, jos on klikattu lomakkeen Peruuta 
       * -painiketta, muuttujassa 'req.body_cancel' on todeksi tulkittava arvo.
       */

      if (req.body._cancel) {
         res.redirect('/opettajat');
         return;
      }

      /*
       * Talletetaan uuden opettajan tiedot tietokantaan ja ohjataan käsittely
       * Kurssi-sivulle (so. polkuun /opettajat/:id), joka esittää uuden 
       * opettajan tiedot.
       * 
       * Kurssin tallettamiseen voidaan käyttää Model-objektin (tässä: Opettaja)
       * create -metodia, jolle annetaan parametriksi opettajan tiedot sisältävä 
       * objekti. Kaikki tiedot tulevat lomakkeelta muuttujassa req.body, joka
       * on sellaisenaan sopiva annettavaksi create -metodin parametriksi.
       * Talletuksen yhteydessä opettajalle muodostuu automaattisesti id. 
       */

      Opettaja.create(req.body).then(function (opettaja) {
         res.redirect('/opettajat/' + opettaja.id);
      });

   });

   /*
    * ----------------------------------------------------------------------
    * Update: Opettajan tietojen muutos
    * ----------------------------------------------------------------------
    */

   /*
    * Lomake opettajan tietojan muutoksia varten
    */
   app.get('/opettajat/:id/update', function (req, res) {

       res.send(req.url);

      /*
       * Haetaa muutettavan opettajan tiedot tietokannasta. Hakuun voidaan 
       * käyttää esim. Model-objektin (tässä: Opettaja) findById-metodia 
       */

      // ... 

         /*
          * Jos opettajaa ei jostakin syystä löydy tietokannasta, hahmonnetaan
          * opettaja_detail -näkymä ilman dataa, ja lopetetaan käsittely tähän.
          */

         // ...


         /*
          * Hahmonnetaan opettaja_update -näkymä välittäen sille opettajan 
          * tämänhetkiset tiedot (opettaja).
          */

         // ...

         
      // });
      
   });


   /*
    * Opettajan tietoihin tehtyjen muutosten talletus tietokantaan
    */
   app.post('/opettajat/update', function (req, res)
   {

       res.redirect('/opettajat/1/update');

      /*
       * Jos käyttäjä klikkaa Päivitä opettaja -sivulla 'Peruuta' -painiketta,
       * ohjataan käsittely Opettaja -sivulle (osoitteeseen /opettajat/:id).
       * 
       * Ao. opettajan id saadaan lomakkeelta, ja se löytyy siten muuttujasta 
       * req.body.id.
       */

       // ...


      /* 
       * Haetaan tietokannasta muutettava objekti lomakkeelta saatavan id:n
       * perusteella.
       */

      // ... 

         /*
          * Muutetaan tietokannasta saatua objektia lomakkelta saaduilla 
          * tiedoilla ja ohjataan käsittely Opettaja-sivulle (/opettajat/:id).
          */

         // ... 


      // });

   });

   /*
    * ----------------------------------------------------------------------
    * Delete: opettajan poisto tietokannasta
    * ----------------------------------------------------------------------
    */

   /*
    * Lomake opettajan tietojan muutoksia varten
    */
   app.get('/opettajat/:id/delete', function (req, res) {

      // res.send(req.url);

      /*
       * Haetaa poistettavan opettajan tiedot tietokannasta. Hakuun voidaan 
       * käyttää esim. Model-objektin (tässä: Opettaja) findById-metodia. 
       */

      Opettaja.findById(req.params.id).then(function (opettaja) {

         /*
          * Jos opettajaa ei jostakin syystä löydy tietokannasta, hahmonnetaan
          * opettaja_detail -näkymä ilman dataa, ja lopetetaan käsittely tähän.
          */

         if (!opettaja) {
            res.render('opettaja_detail');
            return;
         }

         /*
          * Hahmonnetaan opettaja_delete -näkymä välittäen sille opettajan 
          * tämänhetkiset tiedot (opettaja).
          */

         res.render('opettaja_delete', {
            opettaja: opettaja
         });

      });
   });


   /*
    * Opettajan poisto tietokannasta
    */
   app.post('/opettajat/delete', function (req, res) {

      // res.redirect('/opettajat/1/delete');

      /*
       * Jos käyttäjä klikkaa Poistetaanko opettaja -sivulla 'Peruuta' 
       * -painiketta, ohjataan käsittely Opettaja -sivulle 
       * (osoitteeseen /opettaja/:id).
       * 
       * Ao. opettajan id saadaan lomakkeelta, ja se löytyy siten muuttujasta 
       * req.body.id.
       */

      if (req.body._cancel) {
         res.redirect('/opettajat/' + req.body.id);
         return;
      }
      
      /*
       * Haetaan tietokannasta poistettava objekti lomakkeelta saatavan id:n
       * perusteella, postetaan opettaja tietokannasta destroy-metodilla ja
       * ja ohjataan käsittely Opettajat-sivulle (/opettajat).
       */
                 
      Opettaja.findById(req.body.id).then(function (opettaja) {
         return opettaja.destroy();
      }).then(function () {
         res.redirect('/opettajat');
      });
      
   });

};

