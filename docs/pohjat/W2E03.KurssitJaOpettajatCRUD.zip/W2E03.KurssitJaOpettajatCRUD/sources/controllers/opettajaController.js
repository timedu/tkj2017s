
console.log('** opettajaController **');

// TKJ, Tehtävä 2.2

// Nimi: 
// OppNro: 


const Opettaja = require('../models/Opettaja');
const Kurssi = require('../models/Kurssi');


module.exports = function (app) {

   app.get('/opettajat', function (req, res) {

      res.send(req.url);

      // ... (Tehtävästä 2.2)

   });


   app.get('/opettajat/:id', function (req, res) {

      res.send(req.url);

      // ... (Tehtävästä 2.2)

      
   });

};



