
console.log('** kurssiControllerCUD **');

// TKJ, Tehtävä 2.3

// Nimi: 
// OppNro: 

const Kurssi = require('../models/Kurssi');
const Opettaja = require('../models/Opettaja');

module.exports = function (app) {

   /*
    * ----------------------------------------------------------------------
    * Create: uuden kurssi lisäys tietokantaan
    * ----------------------------------------------------------------------
    */

   /*
    * Lomake kurssin tietojan syöttöä varten
    */
   app.get('/kurssit/create', function (req, res) {

       res.send(req.url);

      /*
       * Haetaan tietokannasta kaikki opettajat aakkosjärjestyksesta ja
       * välitetään saatu data tunnuksessa 'opettajat' tietokantahaun 
       * suorituksen jälkeen hahmonnettavalle näkymälle 'kurssi_create'
       * (vrt. opettajaController.js).
       * 
       * Näkymä sisältää lomakkeen kurssin tietojen syöttämistä varten 
       * ja toimii niin, että käyttäjä voi valitta kurssille opettajan
       * näkymän esittämästä opettajaluettelosta.
       */

       // ...

   });

   /*
    * Uuden kurssin talletus tietokantaan
    */
   app.post('/kurssit/create', function (req, res) {

       res.redirect('/kurssit/create');

      /*
       * Jos käyttäjä klikkaa Lisää kurssi -sivulla 'Peruuta' -painiketta,
       * ohjataan käsittely Kurssit -sivulle ja keskeytetään tämän funktion
       * toiminta.
       * 
       * Peruuta-painikkeen name-attribuutin arvo lomakkeessa on '_cancel'.
       * Lomakkeen kaikkien input elementtien vastineet löytyvät req-objektin
       * body-ominaisuudesta. Siten, jos on klikattu lomakkeen Peruuta 
       * -painiketta, muuttujassa 'req.body_cancel' on todeksi tulkittava arvo.
       */

       // ...

      /*
       * Jos lomakkeelta vastaanotettavan opettajatunnuksen (opettajaId) 
       * sisältönä on tyhjä merkkijono, korvataan se arvolla null, joka 
       * tietokannassa tarkoittaa sitä, että kurssille ei ole asetettu
       * opettajaa.
       */


       // ...

      /*
       * Talletetaan uuden kurssin tiedot tietokantaan ja ohjataan käsittely
       * Kurssi-sivulle (so. polkuun /kurssit/:id), joka esittää uuden 
       * kurssin tiedot.
       * 
       * Kurssin tallettamiseen voidaan käyttää Model-objektin (tässä: Kurssi)
       * create -metodia, jolle annetaan parametriksi kurssin tiedot sisältävä 
       * objekti. Kaikki tiedot tulevat lomakkeelta muuttujassa req.body, joka
       * on sellaisenaan sopiva annettavaksi create -metodin parametriksi.
       * Talletuksen yhteydessä kurssille muodostuu automaattisesti id. 
       */

       // ...

   });

   /*
    * ----------------------------------------------------------------------
    * Update: Kurssin tietojen muutos
    * ----------------------------------------------------------------------
    */

   /*
    * Lomake kurssin tietojan muutoksia varten
    */
   app.get('/kurssit/:id/update', function (req, res) {

      /*
       * Haetaa muutettavan kurssin tiedot tietokannasta. Hakuun voidaan 
       * käyttää esim. Model-objektin (tässä: Kurssi) findById-metodia 
       */
      Kurssi.findById(req.params.id).then(function (kurssi) {

         /*
          * Jos kurssia ei jostakin syystä löydy tietokannasta, hahmonnetaan
          * kurssi_detail -näkymä ilman dataa, ja lopetetaan käsittely tähän.
          */
         if (!kurssi) {
            res.render('kurssi_detail');
            return;
         }

         /*
          * Haetaan tietokannasta aakkosjärjestyksesta kaikki opettajat 
          * lomakkeen esittämää opettajaluetteloa varten (vrt. edellä uuden 
          * kurssin lisäys tietokantaan)
          */

         Opettaja.findAll({order: ['sukunimi']}).then(function (opettajat) {

            /*
             * Lisätään kaikille opettajille selected -ominaisuus, joka arvoksi
             * kurssin nykyisen opettajan osalta asetetaan 'selected'. Tämän
             * avulla muutoslomakkeella olevassa luettelossa näkyy valittuna
             * kurssin nykyinen opettaja (ks. kurssi_update.hbs)
             */

            opettajat.forEach((opettaja) => {
               opettaja.selected = opettaja.id === kurssi.opettajaId
                       ? 'selected' : '';
            });

            /*
             * Hahmonnetaan kurssi_update -näkymä välittäen sille kurssin 
             * tämänhetkiset tiedot (kurssi) ja kaikki opettajat opettaja-
             * luetteloa varten (opettajat) 
             */

            res.render('kurssi_update', {
               kurssi: kurssi,
               opettajat: opettajat
            });

         });
      });
   });


   /*
    * Kurssin tietoihin tehtyjen muutosten talletus tietokantaan
    */
   app.post('/kurssit/update', function (req, res)
   {

      /*
       * Jos käyttäjä klikkaa Päivitä kurssi -sivulla 'Peruuta' -painiketta,
       * ohjataan käsittely Kurssi -sivulle (osoitteeseen /kurssit/:id).
       * 
       * Ao. kurssin id saadaan lomakkeelta, ja se löytyy siten muuttujasta 
       * req.body.id.
       */

      if (req.body._cancel) {
         res.redirect('/kurssit/' + req.body.id);
         return;
      }

      /* 
       * Haetaan tietokannasta muutettava objekti lomakkeelta saatavan id:n
       * perusteella.
       */

      Kurssi.findById(req.body.id).then(function (kurssi) {

         /*
          * Jos lomakkeelta vastaanotettavan opettajatunnuksen (opettajaId) 
          * sisältönä on tyhjä merkkijono, korvataan se arvolla null, joka 
          * tietokannassa tarkoittaa sitä, että kurssille ei ole asetettu
          * opettajaa. (vrt. edellä uuden kurssin lisäys tietokantaan)
          */

         if (!req.body.opettajaId.length)
            req.body.opettajaId = null;

         /*
          * Muutetaan tietokannasta saatua objektia lomakkelta saaduilla 
          * tiedoilla ja ohjataan käsittely Kurssi-sivulle (/kurssit/:id).
          */

         kurssi.update(req.body).then(function (kurssi) {
            res.redirect('/kurssit/' + kurssi.id);
         });

      });

   });

   /*
    * ----------------------------------------------------------------------
    * Delete: kurssin poisto tietokannasta
    * ----------------------------------------------------------------------
    */

   /*
    * Lomake kurssin tietojan muutoksia varten
    */
   app.get('/kurssit/:id/delete', function (req, res) {

       res.send(req.url);

      /*
       * Haetaa poistettavan kurssin tiedot tietokannasta. Hakuun voidaan 
       * käyttää esim. Model-objektin (tässä: Kurssi) findById-metodia. 
       * Määritellään haku siten, että samaan pakettiin saadaan kurssin 
       * opettajan tiedot. 
       */

      // ...


         /*
          * Jos kurssia ei jostakin syystä löydy tietokannasta, hahmonnetaan
          * kurssi_detail -näkymä ilman dataa, ja lopetetaan käsittely tähän.
          */

         // ...

         /*
          * Hahmonnetaan kurssi_delete -näkymä välittäen sille kurssin 
          * tämänhetkiset tiedot (kurssi).
          */

         // ...


      // });
      
   });

   /*
    * Kurssin poisto tietokannasta
    */
   app.post('/kurssit/delete', function (req, res) {

       res.redirect('/kurssit/1/delete');

      /*
       * Jos käyttäjä klikkaa Poistetaanko kurssi -sivulla 'Peruuta' 
       * -painiketta, ohjataan käsittely Kurssi -sivulle 
       * (osoitteeseen /kurssit/:id).
       * 
       * Ao. kurssin id saadaan lomakkeelta, ja se löytyy siten muuttujasta 
       * req.body.id.
       */

       // ...
       
      /*
       * Haetaan tietokannasta poistettava objekti lomakkeelta saatavan id:n
       * perusteella, postetaan kurssi tietokannasta destroy-metodilla ja
       * ja ohjataan käsittely Kurssit-sivulle (/kurssit).
       */

       // ...

      
   });
};

