
console.log('** kurssiControllerCUD **');

// TKJ, Tehtävä 2.3

// Nimi: 
// OppNro: 

const Kurssi = require('../models/Kurssi');
const Opettaja = require('../models/Opettaja');

module.exports = function (app) {

   /*
    * Create
    */

   app.get('/kurssit/create', function (req, res) {

       res.send(req.url);
   });

   app.post('/kurssit/create', function (req, res) {

       res.redirect('/kurssit/insert');
   });

   /*
    * Update
    */

   app.get('/kurssit/:id/update', function (req, res) {

      Kurssi.findById(req.params.id).then(function(kurssi) {

         if (!kurssi) {
            res.render('kurssi_detail');
            return;
         }

         Opettaja.findAll({order: ['sukunimi']}).then(function(opettajat) {

            // ao. option-elementin merkintä valituksi
            opettajat.forEach((opettaja) => {
               opettaja.selected = opettaja.id === kurssi.opettajaId ? 'selected' : '';
            });

            res.render('kurssi_update', {
               kurssi: kurssi,
               opettajat: opettajat
            });
         });
      });
   });

   app.post('/kurssit/update', function (req, res)
   {

      if (req.body._cancel) {
         res.redirect('/kurssit/' + req.body.id);
         return;
      }

      Kurssi.findById(req.body.id).then(function(kurssi) {

         if (!req.body.opettajaId.length)
            req.body.opettajaId = null;

         kurssi.update(req.body).then(function(kurssi) {
            res.redirect('/kurssit/' + kurssi.id);
         });
      });
   });

   /*
    * Delete
    */

   app.get('/kurssit/:id/delete', function (req, res) {

       res.send(req.url);      
   });

   app.post('/kurssit/delete', function (req, res) {

       res.redirect('/kurssit/1/delete');
   });
};

