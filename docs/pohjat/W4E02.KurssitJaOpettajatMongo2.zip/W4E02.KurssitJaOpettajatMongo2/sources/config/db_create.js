
/* global Promise */

console.log('** db_create **');

const mongo = require('./db_connection');
const opettajat = require('./db_data'); // tietokantaan talletettava data
const cuid = require('cuid'); // yksilöllisten tunnusten generaattori

mongo(function (db) {

    const promiseOpettajatHasNoDocs = new Promise(function (resolve, reject) {
        db.collection('opettajat').count({}, function (err, count) {
            !!err ? console.error(err) : 1;
            !count ? resolve('ok') : reject('opettajat has docs');
        });
    });

    Promise.all([
        promiseOpettajatHasNoDocs
    ]).then(function () {

        // Kursseille id:t
        opettajat.forEach(function (opettaja) {
            opettaja.kurssis.forEach(function (kurssi) {
                kurssi.id = cuid();
            });
        });

        // Data tietokantaan
        db.collection('opettajat')
                .insert(opettajat, function (err, result) {
                    !err ? console.log('docs created') : console.error(err);
                });

    }).catch(function (reason) {
        console.log(reason);
    });

}); // mongo

