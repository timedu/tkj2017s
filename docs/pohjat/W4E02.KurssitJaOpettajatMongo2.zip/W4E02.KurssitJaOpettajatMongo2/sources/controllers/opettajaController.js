
console.log('** opettajaController **');

// TKJ, Tehtävä 4.2

// Nimi: 
// OppNro: 

const mongo = require('../config/db_connection');
const ObjectID = require('mongodb').ObjectID;
const sortBy = require('../config/sort');  // taulukon lajittelu

module.exports = function (app) {

    app.get('/opettajat', function (req, res) {

         res.send(req.url);

        mongo(function (db) {
            
            // ...

        });

    });

    app.get('/opettajat/:id', function (req, res) {

         res.send(req.url);

        mongo(function (db) {
            
            // ...

        });

    });
};



