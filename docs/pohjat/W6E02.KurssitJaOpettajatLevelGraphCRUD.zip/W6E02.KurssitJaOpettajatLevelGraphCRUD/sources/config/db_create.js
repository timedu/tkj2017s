
/* global __dirname, Promise */

const cuid = require('cuid');
const db = require('./db_connection');
const opettajat = require('./db_data');


module.exports = () => {

   ensureGraphIsEmpty().then(() => {

      const triples = [];

      opettajat.forEach((opettaja) => {

         opettaja_key = cuid();

         triples.push({
            subject: opettaja_key,
            predicate: 'on_opettaja',
            object: JSON.stringify({
               sukunimi: opettaja.sukunimi,
               etunimi: opettaja.etunimi
            })
         });

         opettaja.kurssis.forEach((kurssi) => {

            const kurssi_key = cuid();

            triples.push({
               subject: opettaja_key,
               predicate: "opettaa",
               object: kurssi_key
            });

            triples.push({
               subject: kurssi_key,
               predicate: 'on_kurssi',
               object: JSON.stringify({
                  tunnus: kurssi.tunnus,
                  nimi: kurssi.nimi,
                  laajuus: kurssi.laajuus
               })
            });
         });

      });


      db.put(triples, (err) => {
         err || log_database();
      });

   }, reason => {
      console.log(reason);
   });

}; // module.exports

/**
 * Tulostaa tietokannan koko sisällön
 * @returns {undefined}
 */

function log_database() {

   db.get({predicate: 'on_opettaja'}, (err, list) => {

      console.log('OPETTAJAT:', list);
      
      db.get({predicate: 'on_kurssi'}, (err, list) => {
         
         console.log('KURSSIT:', list);
         
         db.get({predicate: 'opettaa'}, (err, list) => {
            console.log('OPETTAA:', list);
         });
      });
      
   });
}


/**
 * Tarkistaa, sisältääkö tietokanta kolmikkoja
 * @returns {Promise}
 */
function ensureGraphIsEmpty() {

   return new Promise((resolve, reject) => {
//      db.graph.get({limit: 1}, (err, list) => {
      db.get({limit: 1}, (err, list) => {
         if (list.length) {
            reject('db.graph already contains triples');
         } else {
            resolve();
         }
      });
   });
}
