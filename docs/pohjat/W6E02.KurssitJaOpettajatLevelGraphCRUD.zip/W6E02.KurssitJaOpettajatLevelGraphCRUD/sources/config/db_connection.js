
console.log('** db_connection **');


const Level = require('level');
const LevelGraph = require("levelgraph");


module.exports = LevelGraph(Level('./database/koulu.level'));

