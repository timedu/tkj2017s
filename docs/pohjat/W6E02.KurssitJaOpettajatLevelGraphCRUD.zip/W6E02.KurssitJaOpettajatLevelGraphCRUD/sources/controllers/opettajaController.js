

// TKJ, Tehtävä 6.1

// Nimi: 
// OppNro: 


const utils = require('../config/utils');
const sortBy = utils.sortBy;
const normalize = utils.normalize;

const db = require('../config/db_connection');

module.exports = (app) => {

   app.get('/opettajat', (req, res) => {

      res.send(req.url);      
   });

   app.get('/opettajat/:key', (req, res) => {

      res.send(req.url);      
   });
};








