

// TKJ, Tehtävä 6.1

// Nimi: 
// OppNro: 


const utils = require('../config/utils');
const sortBy = utils.sortBy;
const normalize = utils.normalize;

const db = require('../config/db_connection');


module.exports = (app) => {

   app.get('/', (req, res) => {
      res.redirect('/kurssit');
   });


   app.get('/kurssit', (req, res) => {
      
      res.send(req.url);      
   });

   app.get('/kurssit/:key', (req, res) => {

      res.send(req.url);      
   });
};
