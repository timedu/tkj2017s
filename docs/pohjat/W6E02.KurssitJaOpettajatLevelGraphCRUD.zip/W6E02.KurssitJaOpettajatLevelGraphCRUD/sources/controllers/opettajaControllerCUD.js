
// TKJ, Tehtävä 6.2

// Nimi: 
// OppNro: 

const utils = require('../config/utils');
const sortBy = utils.sortBy;
const normalize = utils.normalize;

const db = require('../config/db_connection');
const cuid = require('cuid');


module.exports = function (app) {

   /*
    * ----------------------------------------------------------------------
    * INSERT (CREATE)
    * ----------------------------------------------------------------------
    */

   app.get('/opettajat/insert', (req, res) => {

      res.render('opettaja_insert');
   });

   app.post('/opettajat/insert', (req, res) => {

      if (req.body._cancel) {
         res.redirect('/opettajat');
         return;
      }

      // ...

      res.redirect('/opettajat');

   });

   /*
    * ----------------------------------------------------------------------
    * UPDATE
    * ----------------------------------------------------------------------
    */

   app.get('/opettajat/:key/update', (req, res) => {

      db.get({subject: req.params.key, predicate: 'on_opettaja'}, (err, opettajat) => {

         err ? console.error(err) : 1;

         res.render('opettaja_update', {
            opettaja: normalize(opettajat)[0]
         });

      });
   });

   app.post('/opettajat/update', (req, res) => {

      if (req.body._cancel) {
         res.redirect(`/opettajat/${req.body.key}`);
         return;
      }

      // ...

      res.redirect(`/opettajat/${req.body.key}`);

   }); // app.post


   /*
    * ----------------------------------------------------------------------
    * DELETE
    * ----------------------------------------------------------------------
    */


   app.get('/opettajat/:key/delete', (req, res) => {

      db.get({subject: req.params.key, predicate: 'on_opettaja'}, (err, opettajat) => {

         err ? console.error(err) : 1;

         res.render('opettaja_delete', {
            opettaja: normalize(opettajat)[0]
         });

      });

   });

   app.post('/opettajat/delete', (req, res) => {

      if (req.body._cancel) {
         res.redirect('/opettajat/' + req.body.key);
         return;
      }

      // ...

      res.redirect('/opettajat/' + req.body.key);

   });

};

