
// 170911/TiM 
// - kopioitu tehtävästä 2.3 
// - pieniä muutoksia


var assert = require('assert');
var webdriver = require('selenium-webdriver');
var test = require('selenium-webdriver/testing');
var By = webdriver.By;

/*
 * Use PhantomJS as Browser
 */

var phantomjs_exe = require('phantomjs-prebuilt').path;
var customPhantom = webdriver.Capabilities.phantomjs();
customPhantom.set("phantomjs.binary.path", phantomjs_exe);
var browser = new webdriver.Builder()
        .withCapabilities(customPhantom).build();
const B = browser;
/*
 * Execute Tests
 */

const ServerAddress = 'http://127.0.0.1:3000';


test.describe('kurssit_yllapito:', function () {

   var courseCount; // kurssien lukumäärä testauksen alussa

   test.it('Poimitaan Kurssit-sivulta kurssien lukumäärä', () => {

      B.get(`${ServerAddress}/kurssit`).then(() => {

         B.findElement(By.css('h2')).getText().then((h2Text) => {
            assert.equal(h2Text, 'Kurssit');
         });

         B.findElements(By.css('li a')).then((elements) => {
            courseCount = elements.length;
         });

      });

   });// test.it


   /* 
    * ------------------------------------------------------------------
    * INSERT
    * ------------------------------------------------------------------
    */

// 170907/TiM
//   test.it('tuo esiin Lisää-sivun polulla "/kurssit/insert"', () => {
   test.it('tuo esiin Lisää-sivun polulla "/kurssit/create"', () => {

// 170907/TiM
//      browser.get(`${ServerAddress}/kurssit/insert`).then(() => {
      browser.get(`${ServerAddress}/kurssit/create`).then(() => {
         browser.findElement(By.css('h2')).getText().then((h2Text) => {
            assert.equal(h2Text, 'Lisää kurssi');
         });
      });

   });// test.it


   test.it('Peruuta-painikkeen klikkaus Lisää-sivulla tuo esiin Kurssit-sivun', () => {

// 170907/TiM
//      browser.get(`${ServerAddress}/kurssit/insert`).then(() => {
      browser.get(`${ServerAddress}/kurssit/create`).then(() => {
         browser.findElement(By.css('h2')).getText().then((h2Text) => {
            assert.equal(h2Text, 'Lisää kurssi');
            browser.findElement(By.name('_cancel')).click().then(() => {
               browser.findElement(By.css('h2')).getText().then((h2Text) => {
                  assert.equal(h2Text, 'Kurssit');
               });
            });
         });
      });

   });// test.it

   test.it('Peruuta-painikkeen klikkaus Lisää-sivulla ei lisää kurssien määrää \
Kurssit-sivulle', () => {

      const CourseName = Math.random().toString().substr(0, 20);
      const CourseMark = CourseName.substr(0, 5);

// 170907/TiM
//      B.get(`${ServerAddress}/kurssit/insert`).then(() => {
      B.get(`${ServerAddress}/kurssit/create`).then(() => {
         B.findElement(By.css('h2')).getText().then((h2Text) => {

            assert.equal(h2Text, 'Lisää kurssi');

            B.findElement(By.name('tunnus')).sendKeys(CourseMark).then(() => {
               B.findElement(By.name('nimi')).sendKeys(CourseName).then(() => {

                  B.findElement(By.name('_cancel')).click().then(() => {
                     B.findElements(By.css('li a')).then((elements) => {

                        assert.equal(elements.length, courseCount);

                     });
                  });

               });
            });


         });
      });

   });// test.it


   // seuraavan testin tallettamat tiedot,
   // joita käytetään myöhemmin uudelleen

   var courseId = null; // poimitaan sivulta
   const courseName = Math.random().toString().substr(0, 20);
   const courseMark = courseName.substr(0, 10);
   const newCourseName = Math.random().toString().substr(0, 20);
   const courseInstructor = 'Mikama, Santtu'; // select-elementtiin 'M'


   test.it('Talleta-painikkeen klikkaus Lisää-sivulla esittää lisätyn kurssin Kurssi-sivulla', () => {

// 170907/TiM
//      B.get(`${ServerAddress}/kurssit/insert`).then(() => {
      B.get(`${ServerAddress}/kurssit/create`).then(() => {
         B.findElement(By.css('h2')).getText().then((h2Text) => {

            assert.equal(h2Text, 'Lisää kurssi');

            B.findElement(By.name('tunnus')).sendKeys(courseMark).then(() => {
               B.findElement(By.name('nimi')).sendKeys(courseName).then(() => {
// 170907/TiM
                  B.findElement(By.name('opettaja_id')).sendKeys('M').then(() => {
//                  B.findElement(By.name('opettajaId')).sendKeys('M').then(() => {

// 170907/TiM
//                     B.findElement(By.name('_insert')).click().then(() => {
                     B.findElement(By.name('_create')).click().then(() => {
                        B.findElement(By.css('h2')).getText().then((h2Text) => {

                           assert.equal(h2Text, 'Kurssi');

                        });
                        B.findElement(By.css('body')).getText().then((bodyText) => {

                           assert.ok(bodyText.includes(`Tunnus: ${courseMark}`));
                           assert.ok(bodyText.includes(`Nimi: ${courseName}`));
                           assert.ok(bodyText.includes(`Opettaja: Mikama, Santtu`));

                        });
                        B.findElement(By.linkText('muuta')).getAttribute('href').then((hrefValue) => {

// 170911/TIM 
//                           var match = hrefValue.match(/kurssit\/(\d+)\/update/);
//                           var match = hrefValue.match(/kurssit\/(\.+)\/update/);
                           var match = hrefValue.match(/kurssit\/(.+)\/update/);

                           assert.ok(match);
                           assert.equal(match.length, 2);

                           // poimitaan linkistä talteen lisätyn kurssin tunnus
                           courseId = match[1];

                        });

                     });
                  });
               });
            });
         });
      });

   });// test.it



   /*
    * ------------------------------------------------------------------
    * UPDATE
    * ------------------------------------------------------------------
    */

   test.it('tuo esiin Päivitä-sivun polulla "/kurssit/:id/update", \
joka sisältää odotetut tiedot', () => {

      assert.ok(courseId);

      B.get(`${ServerAddress}/kurssit/${courseId}/update`).then(() => {

         B.findElement(By.css('h2')).getText().then((h2Text) => {
            assert.equal(h2Text, 'Päivitä kurssi');
         });

         B.findElement(By.name('tunnus')).getAttribute('value').then((tunnus) => {
            assert.equal(tunnus, courseMark);
         });

         B.findElement(By.name('nimi')).getAttribute('value').then((nimi) => {
            assert.equal(nimi, courseName);
         });

         B.findElement(By.css('option[selected]')).getText().then((opettaja) => {
            assert.equal(opettaja, courseInstructor);
         });

      });

   });// test.it


   test.it('Peruuta-painikkeen klikkaus Päivitä-sivulla tuo esiin Kurssi-sivun \
niin, että tiedot eivät ole muuttuneet', () => {

      assert.ok(courseId);

      B.get(`${ServerAddress}/kurssit/${courseId}/update`).then(() => {
         B.findElement(By.css('h2')).getText().then((h2Text) => {

            assert.equal(h2Text, 'Päivitä kurssi');

            B.findElement(By.name('nimi')).sendKeys(newCourseName).then(() => {

               B.findElement(By.name('_cancel')).click().then(() => {

                  B.findElement(By.css('h2')).getText().then((h2Text) => {
                     assert.equal(h2Text, 'Kurssi');
                  });

                  B.findElement(By.css('body')).getText().then((bodyText) => {
                     assert.ok(bodyText.includes(`Nimi: ${courseName}`));
                  });

               });

            });

         });
      });

   });// test.it


   test.it('Talleta-painikkeen klikkaus Päivitä-sivulla tuo esiin Kurssi-sivun \
niin, että tiedot ovat muuttuneet', () => {

      assert.ok(courseId);

      B.get(`${ServerAddress}/kurssit/${courseId}/update`).then(() => {

         B.findElement(By.css('h2')).getText().then((h2Text) => {

            assert.equal(h2Text, 'Päivitä kurssi');

            B.findElement(By.name('nimi')).then((nimiInput) => {
               nimiInput.clear().then(() => {
                  nimiInput.sendKeys(newCourseName).then(() => {
                     B.findElement(By.name('_update')).click().then(() => {

                        B.findElement(By.css('h2')).getText().then((h2Text) => {
                           assert.equal(h2Text, 'Kurssi');
                        });

                        B.findElement(By.css('body')).getText().then((bodyText) => {
                           assert.ok(bodyText.includes(`Nimi: ${newCourseName}`));
                        });

                     });
                  });
               });
            });
         });
      });

   });// test.it


   /*
    * ------------------------------------------------------------------
    * DELETE
    * ------------------------------------------------------------------
    */


   test.it('tuo esiin Poistetaanko-sivun polulla "/kurssit/:id/delete", \
joka sisältää odotetut tiedot', () => {

      assert.ok(courseId);

      B.get(`${ServerAddress}/kurssit/${courseId}/delete`).then(() => {

         B.findElement(By.css('h2')).getText().then((h2Text) => {
            assert.equal(h2Text, 'Poistetaanko kurssi?');
         });

         B.findElement(By.css('body')).getText().then((bodyText) => {

            assert.ok(bodyText.includes(`Tunnus: ${courseMark}`));
            assert.ok(bodyText.includes(`Nimi: ${newCourseName}`));
            assert.ok(bodyText.includes(`Opettaja: ${courseInstructor}`));
         });

      });

   });// test.it


   test.it('Peruuta-painikkeen klikkaus Poistetaanko-sivulla tuo esiin Kurssi-sivun \
niin, että tiedot eivät ole poistuneet', () => {

      assert.ok(courseId);

      B.get(`${ServerAddress}/kurssit/${courseId}/delete`).then(() => {
         B.findElement(By.css('h2')).getText().then((h2Text) => {

            assert.equal(h2Text, 'Poistetaanko kurssi?');

            B.findElement(By.name('_cancel')).click().then(() => {

               B.findElement(By.css('h2')).getText().then((h2Text) => {
                  assert.equal(h2Text, 'Kurssi');
               });

               B.findElement(By.css('body')).getText().then((bodyText) => {
                  assert.ok(bodyText.includes(`Nimi: ${newCourseName}`));
               });

            });
         });
      });

   });// test.it


   test.it('Poista-painikkeen klikkaus Poistetaanko-sivulla tuo esiin Kurssit-sivun, \
jossa ei ole poistettuja tietoja', () => {

      assert.ok(courseId);

      B.get(`${ServerAddress}/kurssit/${courseId}/delete`).then(() => {

         B.findElement(By.css('h2')).getText().then((h2Text) => {

            assert.equal(h2Text, 'Poistetaanko kurssi?');

            B.findElement(By.name('_delete')).click().then(() => {

               B.findElement(By.css('h2')).getText().then((h2Text) => {
                  assert.equal(h2Text, 'Kurssit');
               });

               B.findElement(By.css('body')).getText().then((bodyText) => {
                  assert.ok(!bodyText.includes(newCourseName));
               });

               B.findElements(By.css('li a')).then((elements) => {
                  assert.equal(elements.length, courseCount);
               });


            });

         });
      });

   });// test.it


});

