
console.log('** opettajaControllerCUD **');

// TKJ, Tehtävä 4.3

// Nimi: 
// OppNro: 

const mongo = require('../config/db_connection');
const ObjectID = require('mongodb').ObjectID;

module.exports = function (app) {

    /*
     * ----------------------------------------------------------------------
     * Create: uuden opettajan lisäys tietokantaan
     * ----------------------------------------------------------------------
     */

    /*
     * Lomake kurssin tietojan syöttöä varten
     */
    app.get('/opettajat/create', function (req, res) {

        res.render('opettaja_create');
    });

    /*
     * Uuden opettajan talletus tietokantaan
     */
    app.post('/opettajat/create', function (req, res) {

        if (req.body._cancel) {
            res.redirect('/opettajat');
            return;
        }
        delete req.body._create;

        mongo(function (db) {

            // ...

            res.redirect('/opettajat/');
            db.close();

        });

    });

    /*
     * ----------------------------------------------------------------------
     * Update: Opettajan tietojen muutos
     * ----------------------------------------------------------------------
     */

    /*
     * Lomake opettajan tietojan muutoksia varten
     */
    app.get('/opettajat/:id/update', function (req, res) {

        mongo(function (db) {

            const opettajat = db.collection('opettajat');
            const opettajaId = ObjectID(req.params.id);

            opettajat.findOne({'_id': opettajaId}, function (err, opettaja) {
                err ? console.error(err) : 1;
                res.render('opettaja_update', {
                    opettaja: opettaja
                });
                db.close();
            });
        });
    });


    /*
     * Opettajan tietoihin tehtyjen muutosten talletus tietokantaan
     */
    app.post('/opettajat/update', function (req, res)
    {

        if (req.body._cancel) {
            res.redirect('/opettajat/' + req.body.id);
            return;
        }
        delete req.body._update;

        mongo(function (db) {

            // ...

            res.redirect('/opettajat/' + req.body.id);
            db.close();

        });

    });

    /*
     * ----------------------------------------------------------------------
     * Delete: opettajan poisto tietokannasta
     * ----------------------------------------------------------------------
     */

    /*
     * Lomake opettajan tietojan muutoksia varten
     */
    app.get('/opettajat/:id/delete', function (req, res) {

        mongo(function (db) {

            db.collection('opettajat').findOne({'_id': ObjectID(req.params.id)}, function (err, opettaja) {
                err ? console.error(err) : 1;
                res.render('opettaja_delete', {
                    opettaja: opettaja
                });
                db.close();
            });
        });

    });


    /*
     * Opettajan poisto tietokannasta
     */
    app.post('/opettajat/delete', function (req, res) {

        if (req.body._cancel) {
            res.redirect('/opettajat/' + req.body.id);
            return;
        }

        mongo(function (db) {

            // ...

            res.redirect('/opettajat');
            db.close();

        });

    });

};

