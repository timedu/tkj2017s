
console.log('** kurssiController **');

// TKJ, Tehtävä 4.1

// Nimi: 
// OppNro: 


const mongo = require('../config/db_connection');
const ObjectID = require('mongodb').ObjectID;


module.exports = function (app) {

    app.get('/', function (req, res) {
        res.redirect('/kurssit');
    });

    app.get('/kurssit', function (req, res) {

        res.send(req.url);

    });

    app.get('/kurssit/:id', function (req, res) {

        res.send(req.url);

    });

};

