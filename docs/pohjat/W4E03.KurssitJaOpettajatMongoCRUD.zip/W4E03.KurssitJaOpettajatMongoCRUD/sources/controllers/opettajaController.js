
console.log('** opettajaController **');

// TKJ, Tehtävä 4.1

// Nimi: 
// OppNro: 

const mongo = require('../config/db_connection');
const ObjectID = require('mongodb').ObjectID;


module.exports = function (app) {

    app.get('/opettajat', function (req, res) {

         res.send(req.url);
    });

    app.get('/opettajat/:id', function (req, res) {

        mongo(function(db) {

            const opettajat = db.collection('opettajat');
            const kurssit = db.collection('kurssit');

            const opettajaId = ObjectID(req.params.id);

            opettajat.findOne({'_id': opettajaId}, function (err, opettaja) {

                kurssit.find({'opettaja_id': opettajaId})
                        .sort({'nimi': 1})
                        .toArray(function (err, kurssit) {
                            opettaja.kurssit = kurssit;
                            res.render('opettaja_detail', {
                                opettaja: opettaja
                            });
                            db.close();
                        });
            });
        });
    });
};



