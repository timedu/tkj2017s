
console.log('** kurssiControllerCUD **');

// TKJ, Tehtävä 4.3

// Nimi: 
// OppNro: 


const mongo = require('../config/db_connection');
const ObjectID = require('mongodb').ObjectID;


module.exports = function (app) {

    /*
     * ----------------------------------------------------------------------
     * Create: uuden kurssi lisäys tietokantaan
     * ----------------------------------------------------------------------
     */

    /*
     * Lomake kurssin tietojan syöttöä varten
     */
    app.get('/kurssit/create', function (req, res) {

        mongo(function (db) {

            db.collection('opettajat')
                    .find({}).sort({'sukunimi': 1})
                    .toArray(function (err, docs) {

                        err ? console.error(err) : 1;

                        res.render('kurssi_create', {
                            opettajat: docs
                        });
                        db.close();
                    });
        });


    });

    /*
     * Uuden kurssin talletus tietokantaan
     */
    app.post('/kurssit/create', function (req, res) {

        if (req.body._cancel) {
            res.redirect('/kurssit');
            return;
        }

        delete req.body._create;

        if (!req.body.opettaja_id.length) {
            delete req.body.opettaja_id;
        } else {
            req.body.opettaja_id = ObjectID(req.body.opettaja_id);
        }

        mongo(function (db) {

            // ...

            res.redirect('/kurssit/');
            db.close();

        });

    });

    /*
     * ----------------------------------------------------------------------
     * Update: Kurssin tietojen muutos
     * ----------------------------------------------------------------------
     */

    /*
     * Lomake kurssin tietojan muutoksia varten
     */

    app.get('/kurssit/:id/update', function (req, res) {


        mongo(function (db) {

            db.collection('kurssit').findOne({
                '_id': ObjectID(req.params.id)
            }, function (err, kurssi) {

                err ? console.error(err) : 1;

                db.collection('opettajat')
                        .find({}).sort({'sukunimi': 1})
                        .toArray(function (err, opettajat) {

                            err ? console.error(err) : 1;

                            opettajat.forEach(function (opettaja) {
                                opettaja.selected = opettaja._id.equals(kurssi.opettaja_id)
                                        ? 'selected' : '';
                            });

                            res.render('kurssi_update', {
                                kurssi: kurssi,
                                opettajat: opettajat
                            });
                            db.close();
                        });

            });
        });
    });


    /*
     * Kurssin tietoihin tehtyjen muutosten talletus tietokantaan
     */
    app.post('/kurssit/update', function (req, res)
    {

        if (req.body._cancel) {
            res.redirect('/kurssit/' + req.body.id);
            return;
        }

        delete req.body._save;

        if (!req.body.opettaja_id.length) {
            delete req.body.opettaja_id;
        } else {
            req.body.opettaja_id = ObjectID(req.body.opettaja_id);
        }

        var id = req.body.id;
        delete req.body.id;

        mongo(function (db) {

            // ...

            res.redirect('/kurssit/' + id);
            db.close();

        });


    });

    /*
     * ----------------------------------------------------------------------
     * Delete: kurssin poisto tietokannasta
     * ----------------------------------------------------------------------
     */

    /*
     * Lomake kurssin tietojan muutoksia varten
     */
    app.get('/kurssit/:id/delete', function (req, res) {

        mongo(function (db) {

            db.collection('kurssit').findOne({'_id': ObjectID(req.params.id)}, function (err, kurssi) {
                err ? console.error(err) : 1;

                if (kurssi.opettaja_id) {

                    db.collection('opettajat').findOne({'_id': kurssi.opettaja_id}, function (err, opettaja) {
                        kurssi.opettaja = opettaja;
                        db.close();
                        res.render('kurssi_delete', {
                            kurssi: kurssi
                        });
                    });

                } else {
                    db.close();
                    res.render('kurssi_delete', {
                        kurssi: kurssi
                    });
                }

            });
        });

    });


    /*
     * Kurssin poisto tietokannasta
     */
    app.post('/kurssit/delete', function (req, res) {

        if (req.body._cancel) {
            res.redirect('/kurssit/' + req.body.id);
            return;
        }

        mongo(function (db) {

            // ...

            res.redirect('/kurssit');
            db.close();

        });

    });
};

