
console.log('** db_connection **');


/*
 * mLab-tietokantasi tunnukset
 */

//const dbuser = '';
//const dbpassword = '';
//const url = '';


const MongoClient = require('mongodb').MongoClient;

module.exports = function (run) {

   MongoClient.connect(url, function (err, db) {
      if (!err) {         
         run(db);         
      } else {         
         console.error('MongoDB connection failed.', err);
      }      
   });
   
};
