
/* global Promise */

console.log('** db_create **');

const mongo = require('./db_connection');
const opettajat = require('./db_data'); // tietokantaan talletettava data

mongo(function (db) {

    const promiseOpettajatHasNoDocs = new Promise(function (resolve, reject) {
        db.collection('opettajat').count({}, function (err, count) {
            !!err ? console.error(err) : 1;
            !count ? resolve('ok') : reject('opettajat has docs');
        });
    });

    const promiseKurssitHasNoDocs = new Promise(function (resolve, reject) {
        db.collection('kurssit').count({}, function (err, count) {
            !!err ? console.error(err) : 1;
            !count ? resolve('ok') : reject('kurssit has docs');
        });
    });

    Promise.all([
        promiseOpettajatHasNoDocs, promiseKurssitHasNoDocs
    ]).then(function () {

        opettajat.forEach(function (opettaja) {

            // Tietokantaan talletettava opettaja 
            var o = Object.assign({}, opettaja);
            delete o.kurssis; // opettaja-dokumenttiin ei kursseja

            // Opettaja tietokantaan
            db.collection('opettajat').insertOne(o, function (err, result) {

                if (!err) {

                    console.log(result.insertedCount, 'opettajat doc(s) inserted');

                    // Kursseille tietokantaan talletetun opettajan id
                    opettaja.kurssis.forEach(function (kurssi) {
                        kurssi.opettaja_id = result.insertedId;
                    });

                    // Opettajan kurssit tietokantaan
                    db.collection('kurssit').insertMany(opettaja.kurssis, function (err, result) {

                        if (!err) {
                            console.log(result.insertedCount, 'kurssit doc(s) inserted');
                        } else {
                            console.error(err);
                        }
                    });
                } else {
                    console.error(err);
                }
            });
        });

    }).catch(function (reason) {
        console.log(reason);
    });

}); // mongo

