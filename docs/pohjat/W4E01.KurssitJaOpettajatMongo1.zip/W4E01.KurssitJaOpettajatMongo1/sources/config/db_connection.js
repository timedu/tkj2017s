
console.log('** db_connection **');


/*
 * Nämä tunnukset löytyvät Moodlesta
 */

//const dbuser = '';
//const dbpassword = '';
//const url = `mongodb://${dbuser}:${dbpassword}@ds135069.mlab.com:35069/tkj2017k`;


const MongoClient = require('mongodb').MongoClient;

module.exports = function (run) {

   MongoClient.connect(url, function (err, db) {
      if (!err) {         
         run(db);         
      } else {         
         console.error('MongoDB connection failed.', err);
      }      
   });
   
};
