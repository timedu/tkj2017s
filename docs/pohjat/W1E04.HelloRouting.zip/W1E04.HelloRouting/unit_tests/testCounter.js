
var assert = require('assert');

// Testattava moduuli

var counter = require('../sources/counter');

// Testien suoritus

const URL1 = '/abc';
const URL2 = '/def';

var requestsAllExpected = {};

describe('Test Counter', function () {

    it(`ei palauta alussa arvon 0 (parametri: "${URL1}")`, function () {

        assert.equal(counter.getRequests(URL1), 0);
        assert.deepEqual(counter.getRequestsAll(), {});
    });

    it(`palauttaa ensimmäisellä kutsulla arvon 1 (parametri: "${URL1}")`, function () {

        counter.addRequest(URL1);

        requestsAllExpected[URL1] = 1;

        assert.equal(counter.getRequests(URL1), 1);
        assert.deepEqual(counter.getRequestsAll(), requestsAllExpected);
    });

    it(`alkeltaa paluuarvoa seuraavilla kutsuilla (parametri: "${URL1}"`, function () {

        counter.addRequest(URL1);
        counter.addRequest(URL1);

        requestsAllExpected[URL1] = 3;

        assert.equal(counter.getRequests(URL1), 3);
        assert.deepEqual(counter.getRequestsAll(), requestsAllExpected);
    });

    it(`palauttaa arvon 0, kun kutsuja ei olevielä tehty (parametri: "${URL1}")`, function () {

        assert.equal(counter.getRequests(URL2), 0);
    });

    it(`palauttaa ensimmäisellä kutsulla arvon 1 (parametri: "${URL2}")`, function () {

        counter.addRequest(URL2);

        requestsAllExpected[URL2] = 1;

        assert.equal(counter.getRequests(URL2), 1);
        assert.deepEqual(counter.getRequestsAll(), requestsAllExpected);
    });

    it(`jatkaa laskurin askeltamista (parametri: "${URL1}")`, function () {

        counter.addRequest(URL1);

        requestsAllExpected[URL1] = 4;

        assert.equal(counter.getRequests(URL1), 4);
        assert.deepEqual(counter.getRequestsAll(), requestsAllExpected);
    });

});

