

// TKJ, Tehtävä 5.2

// Nimi: 
// OppNro: 

const db = require('../config/db_connection');


module.exports = function (app) {

   app.get('/opettajat', function (req, res) {
      
       res.send(req.url);
      
   });

   app.get('/opettajat/:key', function(req, res) {

       res.send(req.url);

   });

};

