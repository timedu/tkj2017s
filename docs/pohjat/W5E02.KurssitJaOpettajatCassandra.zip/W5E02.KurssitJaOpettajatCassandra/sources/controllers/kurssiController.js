
// TKJ, Tehtävä 5.2

// Nimi: 
// OppNro: 


const db = require('../config/db_connection');


module.exports = function (app) {

    app.get('/', function (req, res) {
        res.redirect('/kurssit');
    });


   app.get('/kurssit', function (req, res) {

       res.send(req.url);
      
   });


   app.get('/kurssit/:key', function (req, res) {

       res.send(req.url);

   });

};


