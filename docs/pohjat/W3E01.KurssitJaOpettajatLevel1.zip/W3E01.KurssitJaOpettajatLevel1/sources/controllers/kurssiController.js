
console.log('** kurssiController **');

// TKJ, Tehtävä 3.1

// Nimi: 
// OppNro: 

const db = require('../config/db_connection');  // tietokantayhteys

module.exports = function (app) {

    app.get('/', function (req, res) {
        res.redirect('/kurssit');
    });

    app.get('/kurssit', function (req, res) {

        res.send('/kurssit');
    });

    app.get('/kurssit/:id', function (req, res) {

        res.send('/kurssit/:id');
    });

};

