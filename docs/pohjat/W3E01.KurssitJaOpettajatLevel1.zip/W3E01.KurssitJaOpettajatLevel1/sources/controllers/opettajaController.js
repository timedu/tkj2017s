
console.log('** opettajaController **');

// TKJ, Tehtävä 3.1

// Nimi: 
// OppNro: 

const db = require('../config/db_connection');  // tietokantayhteys

module.exports = function (app) {

    app.get('/opettajat', function (req, res) {

        // res.send('/opettajat');
    });

    app.get('/opettajat/:id', function (req, res) {

        // res.send('/opettajat/:id');
    });

};



