
/* global Promise */

console.log('** db_create **');

// Tietokannan alustaminen datalla

const db = require('./db_connection');  // tietokantayhteys
const opettajat = require('./db_data'); // tietokantaan talletettava data
const cuid = require('cuid'); // yksilöllisten tunnusten generaattori


const promiseKurssiHasNoRows = new Promise((resolve, reject) => {
    var count = 0;
    db.kurssi.createKeyStream({limit: 1}).on('data', function () {
        count++;
    }).on('end', function () {
        !count ? resolve('ok') : reject('kurssi has data');
    });
});

const promiseOpettajaHasNoRows = new Promise((resolve, reject) => {
    var count = 0;
    db.opettaja.createKeyStream({limit: 1}).on('data', function () {
        count++;
    }).on('end', function () {
        !count ? resolve('ok') : reject('opettaja has data');
    });
});

/*
 * Lupa tietokannan datan talletukselle, jos tietokannasta ei löydy 
 * opettajia eika kursseja
 */

Promise.all([
    promiseOpettajaHasNoRows, promiseKurssiHasNoRows
]).then(function () {

    const dbOpettajat = []; // tietokantaan talletettavat opettajat (key-value)
    const dbKurssit = [];   // tietokantaan talletettavat kurssiy (key-value)

    const opettajaList = [];
    const kurssiList = [];

    /*
     * Datan muokkaus talletusta varten
     */

    opettajat.forEach(function (opettaja) {

        var opettajaId = cuid();

        var dbOpettaja = {
            key: opettajaId,
            value: {
                id: opettajaId,
                sukunimi: opettaja.sukunimi,
                etunimi: opettaja.etunimi,
                kurssis: []
            }
        };

        dbOpettajat.push(dbOpettaja);

        opettajaList.push({
            id: opettajaId,
            sukunimi: opettaja.sukunimi,
            etunimi: opettaja.etunimi
        });

        opettaja.kurssis.forEach(function (kurssi) {

            var kurssiId = cuid();

            var dbKurssi = {
                key: kurssiId,
                value: {
                    id: kurssiId,
                    tunnus: kurssi.tunnus,
                    nimi: kurssi.nimi,
                    laajuus: kurssi.laajuus,
                    opettaja: {
                        id: opettajaId,
                        sukunimi: opettaja.sukunimi,
                        etunimi: opettaja.etunimi
                    }
                }
            };

            dbKurssit.push(dbKurssi);

            kurssiList.push({
                id: kurssiId,
                nimi: kurssi.nimi
            });

            dbOpettaja.value.kurssis.push({
                id: kurssiId,
                nimi: kurssi.nimi
            });

        }); // forEach

        dbOpettaja.value.kurssis = sortBy('nimi', dbOpettaja.value.kurssis);
        
    }); // forEach

    /*
     * Tietokantaan talletettavat luettelot
     */

    dbKurssit.push({
        key: 'list',
        value: sortBy('nimi', kurssiList)
    });

    dbOpettajat.push({
        key: 'list',
        value: sortBy('sukunimi', opettajaList)
    });

    /*
     * Datan talletus tietokantaan
     */

    db.opettaja.batch(dbOpettajat, function (err) {
        if (err) {
            return console.error('Opettaja : unable to create rows', err);
        }
        console.log('Opettaja : rows created');
    });

    db.kurssi.batch(dbKurssit, function (err) {
        if (err) {
            return console.error('Kurssi : unable to create rows', err);
        }
        console.log('Kurssi : rows created');
    });

}).catch(function (reason) {
    console.log(reason);
});


/**
 * Lajitelelee oliotaulukon olion ominaisuuden mukaiseen aakkosjärjestykseen
 * @param {String} p ominaisuus, jonka mukaan lajittelu tapahtuu
 * @param {Array} arr lajiteltava taulukko
 * @returns {Array} lajiteltu taulukko
 */
function sortBy(p, arr) {
    return arr.sort((a, b) => {
        return a[p] <= b[p] ? -1 : 1;
    });
}


