
console.log('** db_create **');

// Tietokannan alustaminen datalla

const opettajat = require('./db_data'); // tietokantaan talletettava data

const Opettaja = require('../models/Opettaja');
const Kurssi = require('../models/Kurssi');

Opettaja.count().then(function (count) {

    // Jos opettaja-taulussa on jo rivejä, tietokantaa ei alusteta 
    // opettaja- ja kurssitiedoilla
    if (count) return;

    opettajat.forEach(function (opettaja) {
        Opettaja.create(opettaja, {include: Kurssi}).catch(function (err) {
            console.error('oops!', err);
        });
    });

}).catch(function (err) {
    console.error('oops!', err);
});


