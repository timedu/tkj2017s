
console.log('** opettajaController **');

// TKJ, Tehtävä 2.2

// Nimi: 
// OppNro: 


const Opettaja = require('../models/Opettaja');
const Kurssi = require('../models/Kurssi');


module.exports = function (app) {

    app.get('/opettajat', function (req, res) {
        res.render('opettaja_list');
    });


    app.get('/opettajat/:id', function (req, res) {

        Opettaja.findById(req.params.id, {
            include: [Kurssi], order: [[Kurssi, 'nimi']]
        }).then(function (opettaja) {
            res.render('opettaja_detail', {
                opettaja: opettaja
            });
        });
    });

};



