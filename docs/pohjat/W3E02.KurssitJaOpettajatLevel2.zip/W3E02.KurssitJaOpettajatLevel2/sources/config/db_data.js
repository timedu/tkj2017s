
console.log('** db_data **');

module.exports = [
    {
        "sukunimi": "Veto",
        "etunimi": "Karri",
        "kurssis": [
            {
                "tunnus": "PLA-32602",
                "nimi": "Tiedonhallinta ja tietokannat",
                "laajuus": "4"
            }, {
                "tunnus": "PLA-33416",
                "nimi": "Software Engineering Management",
                "laajuus": "5"
            }, {
                "tunnus": "PLA-33450",
                "nimi": "Ohjelmistotuotteen hallinta",
                "laajuus": "4"
            }, {
                "tunnus": "PLA-33600",
                "nimi": "Ohjelmistoprojekti",
                "laajuus": "5-9"
            }
        ]
    }, {
        "sukunimi": "Jukola",
        "etunimi": "Leevi",
        "kurssis": [
            {
                "tunnus": "PLA-33120",
                "nimi": "Tietojärjestelmän mallintaminen",
                "laajuus": "5"
            }
        ]
    }, {
        "sukunimi": "Rämeenperä",
        "etunimi": "Niilo",
        "kurssis": [
            {
                "tunnus": "PLA-32200",
                "nimi": "Tietorakenteet",
                "laajuus": "6"
            }
        ]
    }, {
        "sukunimi": "Ahtola",
        "etunimi": "Pertti",
        "kurssis": [
            {
                "tunnus": "PLA-33110",
                "nimi": "Käyttäjäkeskeinen suunnittelu",
                "laajuus": "4"
            }
        ]
    }, {
        "sukunimi": "Mikama",
        "etunimi": "Santtu",
        "kurssis": [
            {
                "tunnus": "PLA-31100",
                "nimi": "Ohjelmointitekniikka",
                "laajuus": "6"
            }, {
                "tunnus": "PLA-32100",
                "nimi": "Olio-ohjelmointi",
                "laajuus": "6"
            }, {
                "tunnus": "PLA-32310",
                "nimi": "Sulautetut järjestelmät",
                "laajuus": "6"
            }, {
                "tunnus": "PLA-32820",
                "nimi": "Mobiiliohjelmointi",
                "laajuus": "5"
            }
        ]
    }, {
        "sukunimi": "Käkilä",
        "etunimi": "Simo",
        "kurssis": [
            {
                "tunnus": "PLA-32610",
                "nimi": "Tietokantajärjestelmät",
                "laajuus": "4"
            }, {
                "tunnus": "PLA-32811",
                "nimi": "Web-ohjelmointi",
                "laajuus": "4"
            }, {
                "tunnus": "PLA-32831",
                "nimi": "Web-selainohjelmointi",
                "laajuus": "4"
            }, {
                "tunnus": "PLA-32841",
                "nimi": "Web-palvelinohjelmointi",
                "laajuus": "4"
            }
        ]
    }
];

