
console.log('** opettajaController **');

// TKJ, Tehtävä 3.2

// Nimi: 
// OppNro: 

const db = require('../config/db_connection');  // tietokantayhteys
const sortBy = require('../config/sort');  // taulukon lajittelu

module.exports = function (app) {

    app.get('/opettajat', function (req, res) {

        res.send('/opettajat');
    });

    app.get('/opettajat/:id', function (req, res) {

        res.send('/opettajat/:id');
    });

};



