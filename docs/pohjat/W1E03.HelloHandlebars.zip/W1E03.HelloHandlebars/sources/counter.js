
// TKJ2017s, Tehtävä 1.3

// Nimi: 
// OppNro: 


var requests = [];

module.exports = function (url) {
    return 9;
};
