
console.log('** opettajaController **');

const db = require('../config/db_connection');

// TKJ, Tehtävä 7.3

// Nimi: 
// OppNro: 

const FindAllOpettajat = '\
SELECT @RID.asString().substring(1) AS key, sukunimi, etunimi \
FROM Opettaja \
ORDER BY sukunimi';

const FindOpettajaByKey = '\
SELECT \
   @RID.substring(1) AS key, \
   sukunimi, \
   etunimi \
FROM Opettaja \
WHERE @RID = :rid';

const FindKurssitUsingEdge = '\
SELECT \
  in.nimi AS nimi,    \
  in.@RID.substring(1) AS key \
FROM Opettaa \
WHERE out = :opettaja_rid\n\
ORDER BY nimi ';


module.exports = app => {

   app.get('/opettajat', (req, res) => {

      // res.send(req.url);

      db.query(FindAllOpettajat).then((result) => {

         res.render('opettaja_list', {
            opettajat: result
         });

      }).catch(err => {

         res.send('error occurred - see console');
         console.error('kurssiController:', err);
      });

   });


   app.get('/opettajat/:key', (req, res) => {

      res.send(req.url);

      // ...

   });

};





