
/* global Promise */

console.log('** kurssiController **');

// TKJ, Tehtävä 7.3

// Nimi: 
// OppNro: 

const db = require('../config/db_connection');

const FindAllKurssit = '\
SELECT @RID.substring(1) AS key, nimi \
FROM Kurssi \
ORDER BY nimi';

const FindOpettajaUsingEdge = '';
const FindValittomatEsitiedot = '';
const FindEsitietoKursseille = '';
const TraverseMuutEsitiedot = '';

module.exports = app => {

   app.get('/', (req, res) => {
      res.redirect('/kurssit');
   });


   app.get('/kurssit', (req, res) => {

      res.send(req.url);
      
      // ...
   });

   app.get('/kurssit/:key', (req, res) => {

      // res.send(req.url);

      db.record.get('#' + req.params.key).then(kurssi => {

         Promise.all([

            db.query(FindOpettajaUsingEdge, {
               params: {kurssi_rid: kurssi['@rid']}
            }),
            db.query(FindValittomatEsitiedot, {
               params: {kurssi_rid: kurssi['@rid']}
            }),
            db.query(FindEsitietoKursseille, {
               params: {kurssi_rid: kurssi['@rid']}
            }),
            db.query(TraverseMuutEsitiedot, {
               params: {kurssi_rid: kurssi['@rid']}
            })

         ]).then(resArr => {

            kurssi.opettaja = resArr[0][0];
            kurssi.valittomat_esitiedot = resArr[1];
            kurssi.esitieto_kursseille = resArr[2];
            kurssi.muut_esitiedot = resArr[3];

            res.render('kurssi_detail', {
               kurssi: kurssi
            });

         }).catch(err => {
            res.send('error occurred - see console');
            console.error('kurssiController:', err);
         });
      }).catch(err => {
         res.send('error occurred - see console');
         console.error('kurssiController:', err);
      });

   });
};


