
console.log('** db_create **');

const db = require('./db_connection');

/*
 * -------------------------------------------------------------------
 * INSERT: Opettajat
 */

const InsertOpettajat = "\
INSERT INTO Opettaja(tunnus, sukunimi, etunimi) \
VALUES \
('vk', 'Veto', 'Karri'),         \
('jv', 'Jukola', 'Leevi'),       \
('rn', 'Rämeenperä', 'Niilo'),   \
('ap', 'Ahtola', 'Pertti'),      \
('ms', 'Mikama', 'Santtu'),      \
('ks', 'Käkilä', 'Simo')         \
";


/*
 * -------------------------------------------------------------------
 * INSERT: Kurssit
 */

const InsertKurssit = "\
INSERT INTO Kurssi(tunnus, nimi, laajuus, o_tunnus) \
VALUES \
('PLA-31100','Ohjelmointitekniikka','6','ms'),           \
('PLA-32100','Olio-ohjelmointi','6','ms'),               \
('PLA-32200','Tietorakenteet','6','rn'),                 \
('PLA-32310','Sulautetut järjestelmät','6','ms'),        \
('PLA-32602','Tiedonhallinta ja tietokannat','4','vk'),  \
('PLA-32610','Tietokantajärjestelmät','4','ks'),         \
('PLA-32811','Web-ohjelmointi','4','ks'),                \
('PLA-32820','Mobiiliohjelmointi','5','ms'),             \
('PLA-32831','Web-selainohjelmointi','4','ks'),          \
('PLA-32841','Web-palvelinohjelmointi','4','ks'),        \
('PLA-33110','Käyttäjäkeskeinen suunnittelu','4','ap'),  \
('PLA-33120','Tietojärjestelmän mallintaminen','5','jv'),\
('PLA-33416','Software Engineering Management','5','vk'),\
('PLA-33450','Ohjelmistotuotteen hallinta','4','vk'),    \
('PLA-33600','Ohjelmistoprojekti','5-9','vk')            \
";


/*
 * -------------------------------------------------------------------
 * module.exports : initialize database
 */

module.exports = () => {

   // --
   // jos tietokantaa ei tarvitse luoda uudelleen, seuraavan
   // return-lauseen voi aktivoida
   // 
//   return;


   Promise.all([

      createClass('Opettaja', 'V'),
      createClass('Kurssi', 'V'),
      createClass('Opettaa', 'E'),
      createClass('OnEsitieto', 'E')

   ]).then(() => {

      Promise.all([

//         db.query('DELETE VERTEX Opettaja'),
//         db.query('DELETE VERTEX Kurssi')

      ]).then(() => {
         
//         log('classes truncated');

         Promise.all([

            db.query(InsertOpettajat),
            db.query(InsertKurssit)

         ]).then(() => {
            
            console.log('records inserted');

            Promise.all([

               createOpettaaEdges('vk'),
               createOpettaaEdges('jv'),
               createOpettaaEdges('rn'),
               createOpettaaEdges('ap'),
               createOpettaaEdges('ms'),
               createOpettaaEdges('ks'),
               createOnEsitietoEdge({
                  kurssi: 'Olio-ohjelmointi',
                  esitieto: 'Ohjelmointitekniikka',
                  tyyppi: 'p'
               }),
               createOnEsitietoEdge({
                  kurssi: 'Tietorakenteet',
                  esitieto: 'Olio-ohjelmointi',
                  tyyppi: 'p'
               }),
               createOnEsitietoEdge({
                  kurssi: 'Sulautetut järjestelmät',
                  esitieto: 'Olio-ohjelmointi',
                  tyyppi: 'p'
               }),
               createOnEsitietoEdge({
                  kurssi: 'Tietokantajärjestelmät',
                  esitieto: 'Olio-ohjelmointi',
                  tyyppi: 's'
               }),
               createOnEsitietoEdge({
                  kurssi: 'Tietokantajärjestelmät',
                  esitieto: 'Tiedonhallinta ja tietokannat',
                  tyyppi: 's'
               }),
               createOnEsitietoEdge({
                  kurssi: 'Tietokantajärjestelmät',
                  esitieto: 'Web-ohjelmointi',
                  tyyppi: 's'
               }),
               createOnEsitietoEdge({
                  kurssi: 'Web-ohjelmointi',
                  esitieto: 'Ohjelmointitekniikka',
                  tyyppi: 'p'
               }),
               createOnEsitietoEdge({
                  kurssi: 'Web-ohjelmointi',
                  esitieto: 'Olio-ohjelmointi',
                  tyyppi: 's'
               }),
               createOnEsitietoEdge({
                  kurssi: 'Web-ohjelmointi',
                  esitieto: 'Tiedonhallinta ja tietokannat',
                  tyyppi: 's'
               }),
               createOnEsitietoEdge({
                  kurssi: 'Mobiiliohjelmointi',
                  esitieto: 'Olio-ohjelmointi',
                  tyyppi: 'p'
               }),
               createOnEsitietoEdge({
                  kurssi: 'Web-selainohjelmointi',
                  esitieto: 'Olio-ohjelmointi',
                  tyyppi: 's'
               }),
               createOnEsitietoEdge({
                  kurssi: 'Web-selainohjelmointi',
                  esitieto: 'Web-ohjelmointi',
                  tyyppi: 's'
               }),
               createOnEsitietoEdge({
                  kurssi: 'Web-palvelinohjelmointi',
                  esitieto: 'Olio-ohjelmointi',
                  tyyppi: 'p'
               }),
               createOnEsitietoEdge({
                  kurssi: 'Web-palvelinohjelmointi',
                  esitieto: 'Tiedonhallinta ja tietokannat',
                  tyyppi: 's'
               }),
               createOnEsitietoEdge({
                  kurssi: 'Web-palvelinohjelmointi',
                  esitieto: 'Web-ohjelmointi',
                  tyyppi: 's'
               }),
               createOnEsitietoEdge({
                  kurssi: 'Software Engineering Management',
                  esitieto: 'Ohjelmointitekniikka',
                  tyyppi: 's'
               }),
               createOnEsitietoEdge({
                  kurssi: 'Ohjelmistotuotteen hallinta',
                  esitieto: 'Ohjelmointitekniikka',
                  tyyppi: 'p'
               }),
               createOnEsitietoEdge({
                  kurssi: 'Ohjelmistotuotteen hallinta',
                  esitieto: 'Tietojärjestelmän mallintaminen',
                  tyyppi: 's'
               }),
               createOnEsitietoEdge({
                  kurssi: 'Ohjelmistotuotteen hallinta',
                  esitieto: 'Software Engineering Management',
                  tyyppi: 's'
               }),
               createOnEsitietoEdge({
                  kurssi: 'Ohjelmistoprojekti',
                  esitieto: 'Ohjelmointitekniikka',
                  tyyppi: 'p'
               }),
               createOnEsitietoEdge({
                  kurssi: 'Ohjelmistoprojekti',
                  esitieto: 'Olio-ohjelmointi',
                  tyyppi: 's'
               }),
               createOnEsitietoEdge({
                  kurssi: 'Ohjelmistoprojekti',
                  esitieto: 'Tiedonhallinta ja tietokannat',
                  tyyppi: 'p'
               }),
               createOnEsitietoEdge({
                  kurssi: 'Ohjelmistoprojekti',
                  esitieto: 'Web-ohjelmointi',
                  tyyppi: 's'
               }),
               createOnEsitietoEdge({
                  kurssi: 'Ohjelmistoprojekti',
                  esitieto: 'Käyttäjäkeskeinen suunnittelu',
                  tyyppi: 's'
               }),
               createOnEsitietoEdge({
                  kurssi: 'Ohjelmistoprojekti',
                  esitieto: 'Tietojärjestelmän mallintaminen',
                  tyyppi: 's'
               }),
               createOnEsitietoEdge({
                  kurssi: 'Ohjelmistoprojekti',
                  esitieto: 'Software Engineering Management',
                  tyyppi: 's'
               }),
               createOnEsitietoEdge({
                  kurssi: 'Ohjelmistoprojekti',
                  esitieto: 'Ohjelmistotuotteen hallinta',
                  tyyppi: 's'
               })

            ]).then(() => {
               console.log('edges created');

            }).catch(error => {
               console.error(error);
            }); // create edges

         }).catch(error => {
            console.error(error);
         }); // insert records

      }).catch(error => {
         console.error(error);
      }); // truncate records

   }).catch(error => {
      console.error(error);
   }); // create classes

}; // module.exports


/**
 * 
 * @param {String} className
 * @param {String} superClassName
 * @returns {Promise}
 */

function createClass(className, superClassName) {

   return new Promise((resolve, reject) => {

      db.class.create(className, superClassName).then((c) => {

//         cosole.log('class created: ' + c.name);
         console.log('class created: ' + c.name);
         resolve();

      }).catch(error => {

//         log(error.message);
//         resolve();
         reject(error.message);
      });

   });
}



const CreateOpettaaEdges = "\
CREATE EDGE Opettaa \
FROM ( SELECT FROM Opettaja WHERE tunnus = :tunnus ) \
TO   ( SELECT FROM Kurssi WHERE o_tunnus = :tunnus ) \
";


function createOpettaaEdges(tunnus) {

   return new Promise((resolve) => {

      db.query(CreateOpettaaEdges, {
         params: {tunnus: tunnus}
      }).then(() => {
         resolve();
      }).catch(error => {

         console.log(error.message);
         resolve();
      });
   });
}

const CreateOnEsitietoEdge = "\
CREATE EDGE OnEsitieto \
FROM ( SELECT FROM Kurssi WHERE nimi = :esitieto ) \
TO   ( SELECT FROM Kurssi WHERE nimi = :kurssi )   \
SET tyyppi = :tyyppi \
";

function createOnEsitietoEdge(edge) {

   return new Promise((resolve) => {

      db.query(CreateOnEsitietoEdge, {
         params: {
            esitieto: edge.esitieto,
            kurssi: edge.kurssi,
            tyyppi: edge.tyyppi
         }
      }).then(() => {
         resolve();

      }).catch(error => {

         console.log(error.message);
         resolve();
      });
   });
}