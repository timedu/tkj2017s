
console.log('** db_connection **');

const ODatabase = require('orientjs').ODatabase;

const db = new ODatabase({
   host: 'localhost',
   port: 2424,
   username: 'admin',
   password: 'admin',
   name: 'KouluGraph'
});

module.exports = db;
