
console.log('** main **');

/* global __dirname */

const Express = require('express');
const app = Express();

app.use(require('body-parser').urlencoded({extended: false}));

app.use(Express.static(__dirname + '/public'));

app.engine('.hbs', require('express-handlebars')({
   defaultLayout: 'main',
   extname: '.hbs',
   layoutsDir: 'sources/views/layouts/'
}));

app.set('view engine', '.hbs');
app.set('views', __dirname + '/views');

require('./controllers/kurssiController')(app);
require('./controllers/opettajaController')(app);

require('./config/db_create')(); // alustaa dataa tietokantaan

const hostname = '127.0.0.1';
const port = 3000;

app.listen(port, hostname, () => {
   console.log('main:', `server running at http://${hostname}:${port}/`);
});

