
console.log('** opettajaController **');


// TKJ, Tehtävä 7.2

// Nimi: 
// OppNro: 


const db = require('../config/db_connection');


const FindAllOpettajat = '\
SELECT @RID.asString().substring(1) AS key, sukunimi, etunimi \
FROM Opettaja \
ORDER BY sukunimi';


// substring 'purisi' vain ensimmäisen kurssin ridiin
const FindOpettajaByKey = '\
SELECT \
   @RID.substring(1) AS key, \
   sukunimi, \
   etunimi, \
   kurssit.@RID AS kurssi_rid, \
   kurssit.nimi AS kurssi_nimi \
FROM Opettaja \
WHERE @RID = :rid';


module.exports = app => {

   app.get('/opettajat', (req, res) => {

       res.send(req.url);
       
       // ...

   });


   app.get('/opettajat/:key', (req, res) => {

      res.send(req.url);

       // ...
      
   });

};

