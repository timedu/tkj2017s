
console.log('** kurssiController **');


const db = require('../config/db_connection');


const FindAllKurssit = '\
SELECT @RID.substring(1) AS key, nimi \
FROM Kurssi \
ORDER BY nimi';


const FindKurssiByKey = '\
SELECT \
  @RID.substring(1) AS key, \
  tunnus,   \
  nimi,     \
  laajuus,  \
  opettaja.sukunimi AS opettaja_sukunimi,    \
  opettaja.etunimi  AS opettaja_etunimi,     \
  opettaja.@RID.substring(1) AS opettaja_key \
FROM Kurssi \
WHERE @RID = :rid';


module.exports = function (app) {

   app.get('/', (req, res) => {
      res.redirect('/kurssit');
   });

   app.get('/kurssit', (req, res) => {

      // res.send(req.url);

      db.query(FindAllKurssit).then((result) => {

         res.render('kurssi_list', {
            kurssit: result
         });

      }).catch(err => {

         res.send('error occurred - see console');
         console.error('kurssiController:', err);
      });

   });


   app.get('/kurssit/:key', (req, res) => {

      // res.send(req.url);

      db.record.get('#' + req.params.key).then(kurssi => {

         if (kurssi.opettaja) {

            db.record.get(kurssi.opettaja).then(opettaja => {

               opettaja.key = opettaja['@rid'].toString().substr(1);
               kurssi.opettaja = opettaja;

               res.render('kurssi_detail', {
                  kurssi: kurssi
               });

            }).catch(err => {
               res.send('error occurred - see console');
               console.error('kurssiController:', err);
            });
         } else {

            res.render('kurssi_detail', {
               kurssi: kurssi
            });
         }

      }).catch(err => {
         res.send('error occurred - see console');
         console.error('kurssiController:', err);
      });

   });

};
