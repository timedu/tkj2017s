

console.log('** opettajaControllerCUD **');


// TKJ, Tehtävä 7.2

// Nimi: 
// OppNro: 


const db = require('../config/db_connection');


module.exports = app => {

   /*
    * INSERT ("CREATE")
    */

   app.get('/opettajat/insert', (req, res) => {
      res.render('opettaja_insert');
   });


   app.post('/opettajat/insert', (req, res) => {

      if (req.body._cancel) {
         res.redirect('/opettajat');
         return;
      }

      res.redirect('/opettajat');

      // ...
      
   });

   /*
    * UPDATE
    */

   app.get('/opettajat/:key/update', (req, res) => {

      // res.send(req.url);

      db.record.get('#' + req.params.key).then(opettaja => {

         opettaja.key = opettaja['@rid'].toString().substr(1);

         res.render('opettaja_update', {
            opettaja: opettaja
         });

      }).catch(err => {
         res.send('error occurred - see console');
         console.error('opettajaControllerCUD:', err);
      });

   });


   app.post('/opettajat/update', (req, res) => {

      if (req.body._cancel) {
         res.redirect(`/opettajat/${req.body.key}`);
         return;
      }

      res.redirect('/opettajat');

      // ...
      
   });


   /*
    * DELETE
    */

   app.get('/opettajat/:key/delete', (req, res) => {

      res.send(req.url);

      // ...

   });

   app.post('/opettajat/delete', (req, res) => {

      if (req.body._cancel) {
         res.redirect('/opettajat/' + req.body.key);
         return;
      }

      res.redirect('/opettajat');

      // ...

   });

};


