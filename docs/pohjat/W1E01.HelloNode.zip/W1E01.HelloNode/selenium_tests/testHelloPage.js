
const assert = require('assert');
const webdriver = require('selenium-webdriver');
const test = require('selenium-webdriver/testing');

/*
 * Use PhantomJS as Browser
 */

var phantomjs_exe = require('phantomjs-prebuilt').path;

var customPhantom = webdriver.Capabilities.phantomjs();
customPhantom.set("phantomjs.binary.path", phantomjs_exe);

var browser = new webdriver.Builder()
        .withCapabilities(customPhantom).build();

/*
 * Perform tests
 */

const ServerAddress = 'http://127.0.0.1:3000';

const URL1 = `/${Math.random()}`;
const URL2 = `/${Math.random()}`;

const getPageAndVerifyContent = (expectedCount, url) => {

    const ExpectedContent = `Hello ${expectedCount} from Node (${url})`;

    browser.get(ServerAddress + url).then(() => {
        browser.getPageSource().then(function (pageSource) {
            assert.ok(pageSource.includes(ExpectedContent),
                    `Sivulta ei löydy tekstiä "${ExpectedContent}"`);
        });
    });
};


test.describe('Hello-sivun testaus', function () {

    test.it('esittää ensimmäisellä pyynnöllä odotetun sisällön', () => {
        getPageAndVerifyContent(1, URL1);
    });

    test.it('kasvattaa laskuria seuraavilla pyynnöillä', () => {
        getPageAndVerifyContent(2, URL1);
        getPageAndVerifyContent(3, URL1);
    });

    test.it('siirtää laskurin alkuun pyynnöllä toiseen polkuun', () => {
        getPageAndVerifyContent(1, URL2);
    });

    test.it('jatkaa ensimmäisen polun laskurin askeltamista', () => {
        getPageAndVerifyContent(4, URL1);
    });

});

