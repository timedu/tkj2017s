
console.log('** db_main **');

/* global __dirname */


// Express-sovelluskehys
const app = require('express')();


// Flash-viestit
app.use(require('cookie-parser')('sectet'));
app.use(require('express-session')({
    resave: true,
    saveUninitialized: true,
    secret: 'secret'
}));
app.use(function (req, res, next) {
    res.locals.flash = req.session.flash;
    delete req.session.flash;
    next();
});
// ref. Ethan Brown (2014). Web Development with Node and Express. p. 105.


// Lomakkeilta vastaanotettavan datan jäsennys
app.use(require('body-parser').urlencoded({extended: false}));


// Sivupohjat
const handlebars = require('express-handlebars');
app.engine('.hbs', handlebars({
    defaultLayout: 'main',
    extname: '.hbs',
    layoutsDir: 'sources/views/layouts/'
}));
app.set('view engine', '.hbs');
app.set('views', __dirname + '/views');


// Tietokannan perustaminen
require('./config/db_create');


// Kontrollerit
require('./controllers/kurssiControllerCUD')(app);
require('./controllers/opettajaControllerCUD')(app);
require('./controllers/kurssiController')(app);
require('./controllers/opettajaController')(app);


// Sovelluksen käynnistys
const hostname = '127.0.0.1', port = 3000;
app.listen(port, hostname, function () {
    console.log(`Server running at http://${hostname}:${port}/`);
});


