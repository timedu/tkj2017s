
console.log('** opettajaControllerCUD **');

// TKJ, Tehtävä 3.3

// Nimi: 
// OppNro: 

const cuid = require('cuid'); // yksilöllisten tunnusten generaattori
const db = require('../config/db_connection');

module.exports = function (app) {

    /*
     * ----------------------------------------------------------------------
     * Create: uuden opettajan lisäys tietokantaan
     * ----------------------------------------------------------------------
     */

    /*
     * Lomake kurssin tietojan syöttöä varten
     */
    app.get('/opettajat/create', function (req, res) {

        res.send(req.url);

        /*
         * Hahmonnetaan näkymä 'opettaja_create', joka sisältää lomakkeen 
         * opettajan tietojen syöttämistä varten. 
         */

         // ...
    });

    /*
     * Uuden opettajan talletus tietokantaan
     */
    app.post('/opettajat/create', function (req, res) {

         res.redirect('/opettajat/create');

        /*
         * Jos käyttäjä klikkaa Lisää Opettaja -sivulla 'Peruuta' -painiketta,
         * ohjataan käsittely Opettajat -sivulle ja keskeytetään tämän funktion
         * toiminta.
         * 
         * Peruuta-painikkeen name-attribuutin arvo lomakkeessa on '_cancel'.
         * Lomakkeen kaikkien input elementtien vastineet löytyvät req-objektin
         * body-ominaisuudesta. Siten, jos on klikattu lomakkeen Peruuta 
         * -painiketta, muuttujassa 'req.body_cancel' on todeksi tulkittava arvo.
         */

         // ...

        /*
         * Poistetaan lomakkeelta vastaanotettujen tietojen joukosta 
         * 'Talleta' -painikkeen klikkaussesta aiheutunut tieto.
         */

         // ...

        /*
         * Talletetaan uuden opettajan tiedot tietokantaan ja ohjataan käsittely
         * Kurssi-sivulle (so. polkuun /opettajat/:id), joka esittää uuden 
         * opettajan tiedot.
         * 
         * Ennen tietojen tallettamista opettajalle muodostetaan yksilöllinen
         * tunniste cuid-funktiolla. Tunniste toimii samalla sekä talletettavan 
         * arvon (value) avaimena (key) että arvona olevan objektin id-
         * ominaisuutena.
         * 
         * flash-ilmoitus:
         * req.session.flash = {message: 'Opettaja lisätty.'};
         */

         // ...

    });

    /*
     * ----------------------------------------------------------------------
     * Update: Opettajan tietojen muutos
     * ----------------------------------------------------------------------
     */

    /*
     * Lomake opettajan tietojan muutoksia varten
     */
    app.get('/opettajat/:id/update', function (req, res) {

         res.send(req.url);

        /*
         * Haetaa muutettavan opettajan tiedot tietokannasta. Hakuun voidaan 
         * käyttää esim. Model-objektin (tässä: Opettaja) findById-metodia 
         */
         
         // ...


            /*
             * Jos opettajaa ei jostakin syystä löydy tietokannasta, hahmonnetaan
             * opettaja_detail -näkymä ilman dataa, ja lopetetaan käsittely tähän.
             */

             // ...
             
            /*
             * Hahmonnetaan opettaja_update -näkymä välittäen sille opettajan 
             * tämänhetkiset tiedot (opettaja).
             */
            
            // ...

            
        // });
    });


    /*
     * Opettajan tietoihin tehtyjen muutosten talletus tietokantaan
     */
    app.post('/opettajat/update', function (req, res)
    {
         res.redirect('/opettajat/1/update');

        /*
         * Jos käyttäjä klikkaa Päivitä opettaja -sivulla 'Peruuta' -painiketta,
         * ohjataan käsittely Opettaja -sivulle (osoitteeseen /opettajat/:id).
         * 
         * Ao. opettajan id saadaan lomakkeelta, ja se löytyy siten muuttujasta 
         * req.body.id.
         */

         // ...

        /*
         * Poistetaan lomakkeelta vastaanotettujen tietojen joukosta 
         * 'Talleta' -painikkeen klikkaussesta aiheutunut tieto.
         */

         // ...

        /*
         * Muutetaan tietokannasta saatua objektia lomakkelta saaduilla 
         * tiedoilla ja ohjataan käsittely Opettaja-sivulle (/opettajat/:id).
         */

        /*
         * Haetaan muutoksen kohteena oleva opetaja tietokannasta
         */

         // ...

            /*
             * Jos opettajaa ei löydy tietokannasta, asetetaan flash-imoitus,
             * ohjataan käsittely osoitteeseen '/opettajat' ja lopetetaan
             * funktion suorittaminen tähän.
             * 
             *  flash:
             req.session.flash = {red: 1,
             message: 'Päivitys ei onnistunut: Opettajaa '
             + req.body.etunimi + ' ' + req.body.sukunimi
             + 'ei ole tietokannassa.'
             */

            // ...

            /*
             * Jos opettajan tietoja on muutettu toisaalla, asetetaan 
             * flash-imoitus, ohjataan käsittely osoitteeseen '/opettajat/:id' 
             * ja lopetetaan funktion suorittaminen tähän.
             * 
             *  flash:
             req.session.flash = {red: 1,
             message: 'Päivitys ei onnistunut: '
             + 'Opettajan tietojan muutettu toisaalta. '
             + 'Yritä uudelleen.'
             };
             */

             // ...
             

            /*
             * Muutetaan tietokannasta saatua objektia lomakkelta saaduilla 
             * tiedoilla ja ohjataan käsittely Opettaja-sivulle (/opettajat/:id).
             * 
             * Ennen muutosta asetetaan opettajalle uusi aikaleima.
             * 
             * flash: 
             req.session.flash = {message: 'Opettaja päivitetty.'}; 
             */

             // ...

        //});

    });

    /*
     * ----------------------------------------------------------------------
     * Delete: opettajan poisto tietokannasta
     * ----------------------------------------------------------------------
     */

    /*
     * Lomake opettajan tietojan muutoksia varten
     */
    app.get('/opettajat/:id/delete', function (req, res) {

         res.send(req.url);

        /*
         * Haetaa poistettavan opettajan tiedot tietokannasta.
         */

         // ...

            /*
             * Jos opettajaa ei jostakin syystä löydy tietokannasta, hahmonnetaan
             * opettaja_detail -näkymä ilman dataa, ja lopetetaan käsittely tähän.
             */

             // ...

            /*
             * Hahmonnetaan opettaja_delete -näkymä välittäen sille opettajan 
             * tämänhetkiset tiedot (opettaja).
             */

             // ...

        // });

    });


    /*
     * Opettajan poisto tietokannasta
     */
    app.post('/opettajat/delete', function (req, res) {

         res.redirect('/opettajat/1/delete');

        /*
         * Jos käyttäjä klikkaa Poistetaanko opettaja -sivulla 'Peruuta' 
         * -painiketta, ohjataan käsittely Opettaja -sivulle 
         * (osoitteeseen /opettaja/:id).
         * 
         * Ao. opettajan id saadaan lomakkeelta, ja se löytyy siten muuttujasta 
         * req.body.id.
         */

         // ...

        /*
         * Haetaan poiston kohteena oleva opetaja tietokannasta
         */


         // ...

            /*
             * Jos opettajaa ei löydy tietokannasta, asetetaan flash-imoitus,
             * ohjataan käsittely osoitteeseen '/opettajat' ja lopetetaan
             * funktion suorittaminen tähän.
             * 
             *  flash:
             message: 'Poisto ei onnistunut: Opettaja '
             + req.body.etunimi + ' ' + req.body.sukunimi
             + 'ei ole tietokannassa.'
             */

            // ...


            /*
             * Jos opettajan tietoja on juuri muutettu toisaalla, asetetaan 
             * flash-imoitus, ohjataan käsittely osoitteeseen '/opettajat/:id' 
             * ja lopetetaan funktion suorittaminen tähän.
             * 
             *  flash:
             message: 'Poisto ei onnistunut: '
             + 'Opettajan tietojan muutettu toisaalta. '
             + 'Yritä uudelleen.'
             };
             */

             // ...

            /*
             * Poistetaan opettaja tietokannasta lomakkeelta saatavan id:n 
             * perusteella ohjataan käsittely Opettajat-sivulle (/opettajat).
             * 
             * flash:
                req.session.flash = {
                    message: 'Opettaja '
                            + req.body.etunimi + ' ' + req.body.sukunimi
                            + ' poistettu tietokannasta.'
                };             
             */

             // ...

        // });

    });

};

