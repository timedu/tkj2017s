
console.log('** kurssiControllerCUD **');

// TKJ, Tehtävä 3.3

// Nimi: 
// OppNro: 

const cuid = require('cuid'); // yksilöllisten tunnusten generaattori
const db = require('../config/db_connection');
const sortBy = require('../config/sort');

module.exports = function (app) {

    /*
     * ----------------------------------------------------------------------
     * Create: uuden kurssi lisäys tietokantaan
     * ----------------------------------------------------------------------
     */

    /*
     * Lomake kurssin tietojan syöttöä varten
     */
    app.get('/kurssit/create', function (req, res) {

        /*
         * Haetaan tietokannasta kaikki opettajat aakkosjärjestyksesta ja
         * välitetään saatu data tunnuksessa 'opettajat' tietokantahaun 
         * suorituksen jälkeen hahmonnettavalle näkymälle 'kurssi_create'
         * (vrt. opettajaController.js).
         * 
         * Näkymä sisältää lomakkeen kurssin tietojen syöttämistä varten 
         * ja toimii niin, että käyttäjä voi valitta kurssille opettajan
         * näkymän esittämästä opettajaluettelosta.
         */

        var opettajat = [];
        db.opettaja.createValueStream().on('data', function (opettaja) {
            opettajat.push(opettaja);
        }).on('end', function () {
            res.render('kurssi_create', {
                opettajat: sortBy('sukunimi', opettajat)
            });
        });

    });

    /*
     * Uuden kurssin talletus tietokantaan
     */
    app.post('/kurssit/create', function (req, res) {


        /*
         * Jos käyttäjä klikkaa Lisää kurssi -sivulla 'Peruuta' -painiketta,
         * ohjataan käsittely Kurssit -sivulle ja keskeytetään tämän funktion
         * toiminta.
         * 
         * Peruuta-painikkeen name-attribuutin arvo lomakkeessa on '_cancel'.
         * Lomakkeen kaikkien input elementtien vastineet löytyvät req-objektin
         * body-ominaisuudesta. Siten, jos on klikattu lomakkeen Peruuta 
         * -painiketta, muuttujassa 'req.body_cancel' on todeksi tulkittava arvo.
         */

        if (req.body._cancel) {
            res.redirect('/kurssit');
            return;
        }

        /*
         * Poistetaan lomakkeelta vastaanotettujen tietojen joukosta 
         * 'Talleta' -painikkeen klikkaussesta aiheutunut tieto.,
         */

        delete req.body._create;

        /*
         * Jos lomakkeelta vastaanotettavan opettajatunnuksen (opettajaId) 
         * sisältönä on tyhjä merkkijono, poistetaan se vastaanotettujen 
         * tietojen joukosta. 
         */

        if (!req.body.opettajaId.length)
            delete req.body.opettajaId;

        /*
         * Talletetaan uuden kurssin tiedot tietokantaan ja ohjataan käsittely
         * Kurssi-sivulle (so. polkuun /kurssit/:id), joka esittää uuden 
         * kurssin tiedot.
         * 
         * Ennen tietojen tallettamista kurssille muodostetaan yksilöllinen
         * tunniste cuid-funktiolla. Tunniste toimii samalla sekä talletettavan 
         * arvon (value) avaimena (key) että arvona olevan objektin id-
         * ominaisuutena.
         */

        const kurssi = req.body;
        kurssi.id = cuid();

        db.kurssi.put(kurssi.id, kurssi, function (err) {

            if (err)
                console.error(err);

            res.redirect('/kurssit/' + kurssi.id);
        });

    });

    /*
     * ----------------------------------------------------------------------
     * Update: Kurssin tietojen muutos
     * ----------------------------------------------------------------------
     */

    /*
     * Lomake kurssin tietojan muutoksia varten
     */
    app.get('/kurssit/:id/update', function (req, res) {

        /*
         * Haetaa muutettavan kurssin tiedot tietokannasta. 
         */

        db.kurssi.get(req.params.id, function (err, kurssi) {

            /*
             * Jos kurssia ei jostakin syystä löydy tietokannasta, hahmonnetaan
             * kurssi_detail -näkymä ilman dataa, ja lopetetaan käsittely tähän.
             */

            if (!kurssi) {
                res.render('kurssi_detail');
                return;
            }

            /*
             * Haetaan tietokannasta aakkosjärjestyksesta kaikki opettajat 
             * lomakkeen esittämää opettajaluetteloa varten (vrt. edellä uuden 
             * kurssin lisäys tietokantaan)
             */

            var opettajat = [];
            db.opettaja.createValueStream().on('data', function (opettaja) {

                /*
                 * Lisätään kaikille opettajille selected -ominaisuus, joka arvoksi
                 * kurssin nykyisen opettajan osalta asetetaan 'selected'. Tämän
                 * avulla muutoslomakkeella olevassa luettelossa näkyy valittuna
                 * kurssin nykyinen opettaja (ks. kurssi_update.hbs)
                 */

                opettaja.selected = opettaja.id === kurssi.opettajaId
                        ? 'selected' : '';

                opettajat.push(opettaja);

            }).on('end', function () {

                /*
                 * Hahmonnetaan kurssi_update -näkymä välittäen sille kurssin 
                 * tämänhetkiset tiedot (kurssi) ja lajiteltuna kaikki 
                 * opettajat opettaja-luetteloa varten (opettajat) 
                 */

                res.render('kurssi_update', {
                    kurssi: kurssi,
                    opettajat: sortBy('sukunimi', opettajat)
                });

            });

        });
    });


    /*
     * Kurssin tietoihin tehtyjen muutosten talletus tietokantaan
     */
    app.post('/kurssit/update', function (req, res)
    {

        /*
         * Jos käyttäjä klikkaa Päivitä kurssi -sivulla 'Peruuta' -painiketta,
         * ohjataan käsittely Kurssi -sivulle (osoitteeseen /kurssit/:id).
         * 
         * Ao. kurssin id saadaan lomakkeelta, ja se löytyy siten muuttujasta 
         * req.body.id.
         */

        if (req.body._cancel) {
            res.redirect('/kurssit/' + req.body.id);
            return;
        }

        /*
         * Poistetaan lomakkeelta vastaanotettujen tietojen jokosta 
         * 'Talleta' -painikkeen klikkaussesta aiheutunut tieto.,
         */

        delete req.body._save;

        /*
         * Jos lomakkeelta vastaanotettavan opettajatunnuksen (opettajaId) 
         * sisältönä on tyhjä merkkijono, korvataan se arvolla null, joka 
         * tietokannassa tarkoittaa sitä, että kurssille ei ole asetettu
         * opettajaa. (vrt. edellä uuden kurssin lisäys tietokantaan)
         */

        if (!req.body.opettajaId.length)
            delete req.body.opettajaId;

        /*
         * Talletetaan mutokset tietokantaan ja ohjataan käsittely 
         * Kurssi-sivulle (/kurssit/:id).
         */
        
        const kurssi = req.body;

        db.kurssi.put(kurssi.id, kurssi, function () {
            res.redirect('/kurssit/' + kurssi.id);
        });

    });

    /*
     * ----------------------------------------------------------------------
     * Delete: kurssin poisto tietokannasta
     * ----------------------------------------------------------------------
     */

    /*
     * Lomake kurssin tietojan muutoksia varten
     */
    app.get('/kurssit/:id/delete', function (req, res) {

        /*
         * Haetaa poistettavan kurssin tiedot tietokannasta. 
         */

        db.kurssi.get(req.params.id, function (err, kurssi) {

            /*
             * Jos kurssia ei jostakin syystä löydy tietokannasta, hahmonnetaan
             * kurssi_detail -näkymä ilman dataa, ja lopetetaan käsittely tähän.
             */

            if (err || !kurssi) {
                res.render('kurssi_detail');
                return;
            }
            
            /*
             * Luetaan kurssin tietojen oheen kurssin opettajan tiedot ja
             * hahmonnetaan kurssi_delete -näkymä välittäen sille kurssin 
             * tämänhetkiset tiedot (kurssi).
             */

            if (kurssi.opettajaId) {

                db.opettaja.get(kurssi.opettajaId, function (err, opettaja) {

                    if (opettaja)
                        kurssi.opettaja = opettaja;

                    res.render('kurssi_delete', {
                        kurssi: kurssi
                    });
                });
            } else {
                res.render('kurssi_delete', {
                    kurssi: kurssi
                });
            }

        });

    });

    /*
     * Kurssin poisto tietokannasta
     */
    app.post('/kurssit/delete', function (req, res) {

        /*
         * Jos käyttäjä klikkaa Poistetaanko kurssi -sivulla 'Peruuta' 
         * -painiketta, ohjataan käsittely Kurssi -sivulle 
         * (osoitteeseen /kurssit/:id).
         * 
         * Ao. kurssin id saadaan lomakkeelta, ja se löytyy siten muuttujasta 
         * req.body.id.
         */

        if (req.body._cancel) {
            res.redirect('/kurssit/' + req.body.id);
            return;
        }

        /*
         * Poistetaan kurssi tietokannasta ja ohjataan käsittely sen 
         * jälkeen Kurssit-sivulle (/kurssit).
         */

        db.kurssi.del(req.body.id, function () {
            res.redirect('/kurssit');
        });

    });
};

