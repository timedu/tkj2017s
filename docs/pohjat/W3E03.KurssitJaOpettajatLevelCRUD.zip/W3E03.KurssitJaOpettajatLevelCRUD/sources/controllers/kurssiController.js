
console.log('** kurssiController **');

// TKJ, Tehtävä 3.2

// Nimi: 
// OppNro: 

const db = require('../config/db_connection');  // tietokantayhteys
const sortBy = require('../config/sort');  // taulukon lajittelu

module.exports = function (app) {

    app.get('/', function (req, res) {
        res.redirect('/kurssit');
    });

    app.get('/kurssit', function (req, res) {

        var kurssit = [];
        db.kurssi.createValueStream().on('data', function (kurssi) {
            kurssit.push(kurssi);
        }).on('end', function () {
            res.render('kurssi_list', {
                kurssit: sortBy('nimi', kurssit)
            });
        });

    });

    app.get('/kurssit/:id', function (req, res) {

        res.send(req.url);
    });

};

