
/* global Promise */

console.log('** db_create **');

// Tietokannan alustaminen datalla

const db = require('./db_connection');  // tietokantayhteys
const opettajat = require('./db_data'); // tietokantaan talletettava data
const cuid = require('cuid'); // yksilöllisten tunnusten generaattori


const promiseKurssiHasNoRows = new Promise((resolve, reject) => {
    var count = 0;
    db.kurssi.createKeyStream({limit: 1}).on('data', function () {
        count++;
    }).on('end', function () {
        !count ? resolve('ok') : reject('kurssi has data');
    });
});

const promiseOpettajaHasNoRows = new Promise((resolve, reject) => {
    var count = 0;
    db.opettaja.createKeyStream({limit: 1}).on('data', function () {
        count++;
    }).on('end', function () {
        !count ? resolve('ok') : reject('opettaja has data');
    });
});

/*
 * Lupa tietokannan datan talletukselle, jos tietokannasta ei löydy 
 * opettajia eika kursseja
 */

Promise.all([
    promiseOpettajaHasNoRows, promiseKurssiHasNoRows
]).then(function () {

    const dbOpettajat = []; // tietokantaan talletettavat opettajat (key-value)
    const dbKurssit = [];   // tietokantaan talletettavat kurssiy (key-value)

    /*
     * Datan muokkaus talletusta varten
     */

    opettajat.forEach(function (opettaja) {

        var opettajaId = cuid();

        var dbOpettaja = {
            key: opettajaId,
            value: {
                id: opettajaId,
                sukunimi: opettaja.sukunimi,
                etunimi: opettaja.etunimi,
                _timestamp: Date.now()
            }
        };

        dbOpettajat.push(dbOpettaja);

        opettaja.kurssis.forEach(function (kurssi) {

            var kurssiId = cuid();

            var dbKurssi = {
                key: kurssiId,
                value: {
                    id: kurssiId,
                    tunnus: kurssi.tunnus,
                    nimi: kurssi.nimi,
                    laajuus: kurssi.laajuus,
                    opettajaId: opettajaId
                }
            };

            dbKurssit.push(dbKurssi);
            
        }); // forEach
        
    }); // forEach

    /*
     * Datan talletus tietokantaan
     */

    db.opettaja.batch(dbOpettajat, function (err) {
        if (err) {
            return console.error('Opettaja : unable to create rows', err);
        }
        console.log('Opettaja : rows created');
    });

    db.kurssi.batch(dbKurssit, function (err) {
        if (err) {
            return console.error('Kurssi : unable to create rows', err);
        }
        console.log('Kurssi : rows created');
    });

}).catch(function (reason) {
    console.log(reason);
});

