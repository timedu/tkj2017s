
/**
 * Lajitelelee oliotaulukon olion ominaisuuden mukaiseen aakkosjärjestykseen
 * @param {String} p ominaisuus, jonka mukaan lajittelu tapahtuu
 * @param {Array} arr lajiteltava taulukko
 * @returns {Array} lajiteltu taulukko
 */

module.exports = function sortBy(p, arr) {
    return arr.sort((a, b) => {
        return a[p] <= b[p] ? -1 : 1;
    });
};

