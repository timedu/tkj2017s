
console.log('** db_connection **');

const Level = require('level');

module.exports = {
   kurssi: Level('./database/kurssi.level',{
       valueEncoding: 'json'
   }),
   opettaja: Level('./database/opettaja.level', {
       valueEncoding: 'json'
   })
};

