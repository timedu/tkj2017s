
// 170912/TiM 
// - muutos (ks. ao kohta)

// 170911/TiM
// - kopioitu tehtävästä 2.3
// - pieni muutos (ks. ao kohta)

var assert = require('assert');
var webdriver = require('selenium-webdriver');
var test = require('selenium-webdriver/testing');
var By = webdriver.By;

/*
 * Use PhantomJS as Browser
 */

var phantomjs_exe = require('phantomjs-prebuilt').path;
var customPhantom = webdriver.Capabilities.phantomjs();
customPhantom.set("phantomjs.binary.path", phantomjs_exe);
var browser = new webdriver.Builder()
        .withCapabilities(customPhantom).build();
const B = browser;
/*
 * Execute Tests
 */

const ServerAddress = 'http://127.0.0.1:3000';


test.describe('opettajat_yllapito:', function () {

   var instructorCount; // opettajien lukumäärä testauksen alussa

   test.it('Poimitaan Opettajat-sivulta opettajien lukumäärä', () => {

      B.get(`${ServerAddress}/opettajat`).then(() => {

         B.findElement(By.css('h2')).getText().then((h2Text) => {
            assert.equal(h2Text, 'Opettajat');
         });

         B.findElements(By.css('li a')).then((elements) => {
            instructorCount = elements.length;
         });

      });

   });// test.it


   /*
    * ------------------------------------------------------------------
    * INSERT
    * ------------------------------------------------------------------
    */

// 170907/TiM
//   test.it('tuo esiin Lisää-sivun polulla "/opettajat/insert"', () => {
   test.it('tuo esiin Lisää-sivun polulla "/opettajat/create"', () => {

// 170907/TiM
//      browser.get(`${ServerAddress}/opettajat/insert`).then(() => {
      browser.get(`${ServerAddress}/opettajat/create`).then(() => {
         browser.findElement(By.css('h2')).getText().then((h2Text) => {
            assert.equal(h2Text, 'Lisää opettaja');
         });
      });

   });// test.it


   test.it('Peruuta-painikkeen klikkaus Lisää-sivulla tuo esiin Opettajat-sivun', () => {

// 170907/TiM
//      browser.get(`${ServerAddress}/opettajat/insert`).then(() => {
      browser.get(`${ServerAddress}/opettajat/create`).then(() => {
         browser.findElement(By.css('h2')).getText().then((h2Text) => {
            assert.equal(h2Text, 'Lisää opettaja');
            browser.findElement(By.name('_cancel')).click().then(() => {
               browser.findElement(By.css('h2')).getText().then((h2Text) => {
                  assert.equal(h2Text, 'Opettajat');
               });
            });
         });
      });

   });// test.it

   test.it('Peruuta-painikkeen klikkaus Lisää-sivulla ei lisää kurssien määrää \
Kurssit-sivulle', () => {

      const Instructor = Math.random().toString().substr(0, 20);

// 170907/TiM
//      B.get(`${ServerAddress}/opettajat/insert`).then(() => {
      B.get(`${ServerAddress}/opettajat/create`).then(() => {
         B.findElement(By.css('h2')).getText().then((h2Text) => {

            assert.equal(h2Text, 'Lisää opettaja');

            B.findElement(By.name('sukunimi')).sendKeys(Instructor).then(() => {

               B.findElement(By.name('_cancel')).click().then(() => {
                  B.findElements(By.css('li a')).then((elements) => {

                     assert.equal(elements.length, instructorCount);

                  });
               });

            });
         });
      });

   });// test.it


   // seuraavan testin tallettamat tiedot,
   // joita käytetään myöhemmin uudelleen

   var instructorId = null; // poimitaan sivulta
   const instructor = Math.random().toString().substr(0, 20);
   const newInstructor = Math.random().toString().substr(0, 20);

   test.it('Talleta-painikkeen klikkaus Lisää-sivulla esittää lisätyn opettajan Opettaja-sivulla', () => {

// 170907/TiM
//      B.get(`${ServerAddress}/opettajat/insert`).then(() => {
      B.get(`${ServerAddress}/opettajat/create`).then(() => {
         B.findElement(By.css('h2')).getText().then((h2Text) => {

            assert.equal(h2Text, 'Lisää opettaja');

            B.findElement(By.name('sukunimi')).sendKeys(instructor).then(() => {
// 170907/TiM
//               B.findElement(By.name('_insert')).click().then(() => {
               B.findElement(By.name('_save')).click().then(() => {
                  B.findElement(By.css('h2')).getText().then((h2Text) => {

                     assert.equal(h2Text, 'Opettaja');

                  });
                  B.findElement(By.css('body')).getText().then((bodyText) => {

                     assert.ok(bodyText.includes(`Sukunimi: ${instructor}`));

                  });
                  B.findElement(By.linkText('muuta')).getAttribute('href').then((hrefValue) => {

// 170911/TiM
//                     var match = hrefValue.match(/opettajat\/(\d+)\/update/);
                     var match = hrefValue.match(/opettajat\/(.+)\/update/);

                     assert.ok(match);
                     assert.equal(match.length, 2);

                     // poimitaan linkistä talteen lisätyn kurssin tunnus
                     instructorId = match[1];

                  });
               });
            });
         });
      });

   });// test.it



   /*
    * ------------------------------------------------------------------
    * UPDATE
    * ------------------------------------------------------------------
    */

   test.it('tuo esiin Päivitä-sivun polulla "/opettajat/:id/update", \
joka sisältää odotetut tiedot', () => {

      assert.ok(instructorId);

      B.get(`${ServerAddress}/opettajat/${instructorId}/update`).then(() => {

         B.findElement(By.css('h2')).getText().then((h2Text) => {
            assert.equal(h2Text, 'Päivitä opettaja');
         });

         B.findElement(By.name('sukunimi')).getAttribute('value').then((sukunimi) => {
            assert.equal(sukunimi, instructor);
         });

      });

   });// test.it


   test.it('Peruuta-painikkeen klikkaus Päivitä-sivulla tuo esiin Opettaja-sivun \
niin, että tiedot eivät ole muuttuneet', () => {

      assert.ok(instructorId);

      B.get(`${ServerAddress}/opettajat/${instructorId}/update`).then(() => {
         B.findElement(By.css('h2')).getText().then((h2Text) => {

            assert.equal(h2Text, 'Päivitä opettaja');

            B.findElement(By.name('sukunimi')).sendKeys(newInstructor).then(() => {

               B.findElement(By.name('_cancel')).click().then(() => {

                  B.findElement(By.css('h2')).getText().then((h2Text) => {
                     assert.equal(h2Text, 'Opettaja');
                  });

                  B.findElement(By.css('body')).getText().then((bodyText) => {
                     assert.ok(bodyText.includes(`Sukunimi: ${instructor}`));
                  });

               });

            });

         });
      });

   });// test.it


   test.it('Talleta-painikkeen klikkaus Päivitä-sivulla tuo esiin Opettaja-sivun \
niin, että tiedot ovat muuttuneet', () => {

      assert.ok(instructorId);

      B.get(`${ServerAddress}/opettajat/${instructorId}/update`).then(() => {

         B.findElement(By.css('h2')).getText().then((h2Text) => {

            assert.equal(h2Text, 'Päivitä opettaja');

            B.findElement(By.name('sukunimi')).then((nimiInput) => {
               nimiInput.clear().then(() => {
                  nimiInput.sendKeys(newInstructor).then(() => {
                     B.findElement(By.name('_update')).click().then(() => {

                        B.findElement(By.css('h2')).getText().then((h2Text) => {
                           assert.equal(h2Text, 'Opettaja');
                        });

                        B.findElement(By.css('body')).getText().then((bodyText) => {
                           assert.ok(bodyText.includes(`Sukunimi: ${newInstructor}`));
                        });

                     });
                  });
               });
            });
         });
      });

   });// test.it


   /*
    * ------------------------------------------------------------------
    * DELETE
    * ------------------------------------------------------------------
    */


   test.it('tuo esiin Poistetaanko-sivun polulla "/opettajat/:id/delete", \
joka sisältää odotetut tiedot', () => {

      assert.ok(instructorId);

      B.get(`${ServerAddress}/opettajat/${instructorId}/delete`).then(() => {

         B.findElement(By.css('h2')).getText().then((h2Text) => {
            assert.equal(h2Text, 'Poistetaanko opettaja?');
         });

         B.findElement(By.css('body')).getText().then((bodyText) => {

            assert.ok(bodyText.includes(`Sukunimi: ${newInstructor}`));
         });

      });

   });// test.it


   test.it('Peruuta-painikkeen klikkaus Poistetaanko-sivulla tuo esiin Opettaja-sivun \
niin, että tiedot eivät ole poistuneet', () => {

      assert.ok(instructorId);

      B.get(`${ServerAddress}/opettajat/${instructorId}/delete`).then(() => {
         B.findElement(By.css('h2')).getText().then((h2Text) => {

            assert.equal(h2Text, 'Poistetaanko opettaja?');

            B.findElement(By.name('_cancel')).click().then(() => {

               B.findElement(By.css('h2')).getText().then((h2Text) => {
                  assert.equal(h2Text, 'Opettaja');
               });

               B.findElement(By.css('body')).getText().then((bodyText) => {
                  assert.ok(bodyText.includes(`Sukunimi: ${newInstructor}`));
               });

            });
         });
      });

   });// test.it


   test.it('Poista-painikkeen klikkaus Poistetaanko-sivulla tuo esiin Opettajat-sivun, \
jossa ei ole poistettuja tietoja', () => {

      assert.ok(instructorId);

      B.get(`${ServerAddress}/opettajat/${instructorId}/delete`).then(() => {

         B.findElement(By.css('h2')).getText().then((h2Text) => {

            assert.equal(h2Text, 'Poistetaanko opettaja?');

            B.findElement(By.name('_delete')).click().then(() => {

               B.findElement(By.css('h2')).getText().then((h2Text) => {
                  assert.equal(h2Text, 'Opettajat');
               });

// 170912/TiM 
//               B.findElement(By.css('body')).getText().then((bodyText) => {
//                  assert.ok(!bodyText.includes(newInstructor));
//               });
               B.findElement(By.css('ul')).getText().then((ulText) => {
                  assert.ok(!ulText.includes(newInstructor));
               });


               B.findElements(By.css('li a')).then((elements) => {
                  assert.equal(elements.length, instructorCount);
               });

            });

         });
      });

   });// test.it


});

