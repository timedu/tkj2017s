
// TKJ2017s, Tehtävä 1.5

// Nimi: 
// OppNro: 

var requests = {};

module.exports = {
    
    addRequest: function (url) {
        requests[url] = requests[url] ? ++requests[url] : 1;
    },
    
    getRequests: function (url) {
        return requests[url] ? requests[url] : 0;
    },
    
    getRequestsAll: function () {
        return requests;
    }
    
};
