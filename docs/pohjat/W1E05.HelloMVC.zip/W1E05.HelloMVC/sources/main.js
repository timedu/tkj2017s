

/* global __dirname */

// TKJ2017s, Tehtävä 1.5

// Nimi: 
// OppNro: 


/*
 * Tarvittavat paketit: express, express-handlebars
 */

var app = require('express')();
var handlebars = require('express-handlebars');


/*
 * Handlebars-astukset
 */

app.engine('.hbs', handlebars({
    defaultLayout: 'main',
    extname: '.hbs',
    layoutsDir: 'sources/views/layouts/'
}));
app.set('view engine', '.hbs');
app.set('views', __dirname + '/views');


/*
 * Model (counter) ja controller
 */

const counter = require('./counter');
const controller = require('./controller');

controller.init(app, counter);


/*
 * Sovelluksen käynnistys
 */

const hostname = '127.0.0.1', port = 3000;
app.listen(port, hostname, () => {
    console.log(`Server running at http://${hostname}:${port}/`);
});


