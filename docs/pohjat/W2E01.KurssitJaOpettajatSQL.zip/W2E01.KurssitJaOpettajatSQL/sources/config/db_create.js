

console.log('** db_create **');


const db = require('./db_connection');  // tietokantayhteys
const opettajat = require('./db_data'); // tietokantaan talletettava data


db.serialize(function () { // tietokantakomennot suoritetaan peräkkäin

    db.run('\
            CREATE TABLE opettaja (                                 \
                id          INTEGER     PRIMARY KEY AUTOINCREMENT,  \
                sukunimi    VARCHAR(30) NOT NULL,                   \
                etunimi     VARCHAR(30)                             \
        )');

    db.run('\
            CREATE TABLE kurssi (                                   \
                id          INTEGER     PRIMARY KEY AUTOINCREMENT,  \
                tunnus      VARCHAR(10) UNIQUE NOT NULL,            \
                nimi        VARCHAR(30) UNIQUE NOT NULL,            \
                laajuus     VARCHAR(10),                            \
                opettaja_id INTEGER     REFERENCES opettaja (id)    \
                                        ON DELETE SET NULL          \
        )');

    const InsertOpettaja = db.prepare('\
            INSERT INTO opettaja(sukunimi, etunimi) \
            VALUES (?,?)');

    const InsertKurssi = db.prepare('\
            INSERT INTO kurssi(tunnus, nimi, laajuus, opettaja_id) \
            VALUES (?,?,?,?)');

    opettajat.forEach(function (opettaja, i) {

        InsertOpettaja.run([
            opettaja.sukunimi,
            opettaja.etunimi
        ], function () {
            
            var opettaja_id = this.lastID; // opettajalle muodostunut id

            opettaja.kurssit.forEach(function (kurssi, j) {
                InsertKurssi.run([
                    kurssi.tunnus,
                    kurssi.nimi,
                    kurssi.laajuus,
                    opettaja_id
                ]);
            }); // forEach
        });
    }); // forEach
    
});


