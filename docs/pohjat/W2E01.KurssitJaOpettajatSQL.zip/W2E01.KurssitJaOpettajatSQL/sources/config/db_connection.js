
console.log('** db_connection **');

// SQLite-kirjaston käyttöönotto
const sqlite3 = require('sqlite3').verbose();

// Muistinvaraisen SQLite-tietokannan perustaminen
const db = new sqlite3.Database(':memory:');

// Tietokantayhteyden julkaisu
module.exports = db;


