
console.log('** kurssiController **');

const db = require('../config/db_connection');


// TKJ, Tehtävä 2.1

// Nimi: 
// OppNro: 


const FindAllKurssit = '';


const FindOneKurssi = '\
    SELECT \
        k.*,                            \
        o.etunimi AS opettaja_etunimi,  \
        o.sukunimi AS opettaja_sukunimi \
    FROM kurssi AS k LEFT OUTER JOIN opettaja AS o \
        ON k.opettaja_id = o.id         \
    WHERE k.tunnus = ?';


module.exports = function (app) {

    app.get('/', function (req, res) {
        res.redirect('/kurssit');
    });


    app.get('/kurssit', function (req, res) {

        res.render('kurssi_list');
    });


    app.get('/kurssit/:tunnus', function (req, res) {

        db.get(FindOneKurssi, req.params.tunnus, function (err, row) {

            res.render('kurssi_detail', {
                kurssi: row
            });
        });
    });

};

