
console.log('** opettajaController **');

const db = require('../config/db_connection');


// TKJ, Tehtävä 2.1

// Nimi: 
// OppNro: 


const FindAllOpettajat = '\
    SELECT id, sukunimi, etunimi    \
    FROM opettaja                   \
    ORDER BY sukunimi';

const FindOpettajaById = '';

const FindOpettajanKurssit = '';


module.exports = function (app) {

    app.get('/opettajat', function (req, res) {

        db.all(FindAllOpettajat, function (err, rows) {

            res.render('opettaja_list', {
                opettajat: rows
            });
        });
    });

    app.get('/opettajat/:id', function (req, res) {

        res.render('opettaja_detail');
    });

};



