
/* global Promise */

//var assert = require('assert');
var assert = require('chai').assert;

var webdriver = require('selenium-webdriver');
var test = require('selenium-webdriver/testing');
var By = webdriver.By;

/*
 * Use PhantomJS as Browser
 */

var phantomjs_exe = require('phantomjs-prebuilt').path;
var customPhantom = webdriver.Capabilities.phantomjs();
customPhantom.set("phantomjs.binary.path", phantomjs_exe);
var browser = new webdriver.Builder()
        .withCapabilities(customPhantom).build();

/*
 * Execute Tests
 */

const ServerAddress = 'http://127.0.0.1:3000';


test.describe('kurssi-kyselyt:', function () {

   var tests_succeeded_so_far = false;

   // -------------------------------------------------------------------
   test.it('Kurssit-sivulla on odotettu sisältö', () => {
      // ----------------------------------------------------------------


      /*
       * Siirrytään Kurssit -sivulle
       */

      browser.get(`${ServerAddress}/kurssit`).then(() => {

         /*
          * Sivulla on otsikko "Kurssit"
          */

         browser.findElement(By.css('h2')).getText().then((h2Text) => {
            assert.ok(h2Text.includes('Kurssit'),
                    `Sivulla on otsikko "${h2Text}"; pitäisi olla "Kurssit"`);
         });

         /*
          * Sivulla on 15 kurssia
          */

// 170305/TiM
//         browser.findElements(By.css('li a')).then((kurssiLinks) => {
//            assert.equal(kurssiLinks.length, 15,
//                    `Sivulla on kursseja (li a) "${kurssiLinks.length}"; pitäisi olla "15"`);
//         });
         browser.findElements(By.css('li a')).then((kurssiLinks) => {
            assert.equal(kurssiLinks.length, 16,
                    `Sivulla on kursseja (li a) "${kurssiLinks.length}"; pitäisi olla "16"`);
         });
//

         /*
          * Sivulla on kurssit "Mobiiliohjelmointi", "Ohjelmistoprojekti" ja 
          * "Ohjelmistotuotteen hallinta" 
          */

         browser.findElement(By.css('body')).getText().then((bodyText) => {

            assert.ok(bodyText.includes('Mobiiliohjelmointi'),
                    'Sivulta ei löydy kurssia "Mobiiliohjelmointi"');

            assert.ok(bodyText.includes('Ohjelmistoprojekti'),
                    'Sivulta ei löydy kurssia "Ohjelmistoprojekti"');

            assert.ok(bodyText.includes('Ohjelmistotuotteen hallinta'),
                    'Sivulta ei löydy kurssia "Ohjelmistotuotteen hallinta"');

         });

         /*
          * Kurssit ovat aakkosjärjestyksessä
          */

         browser.findElements(By.css('li a')).then((kurssiLinks) => {

// 170305/TiM
//            kurssiLinks[1].getText().then((elementText) => {
//               assert.ok(elementText.includes("Mobiiliohjelmointi"),
//                       `2. kurssi pitäisi olla "Mobiiliohjelmointi"; 2. kurssi on "${elementText}"`);
//            });
//
//            kurssiLinks[2].getText().then((elementText) => {
//               assert.ok(elementText.includes("Ohjelmistoprojekti"),
//                       `3. kurssi pitäisi olla "Ohjelmistoprojekti"; 3. kurssi on "${elementText}"`);
//            });
//
//            kurssiLinks[3].getText().then((elementText) => {
//               assert.ok(elementText.includes("Ohjelmistotuotteen hallinta"),
//                       `4. kurssi pitäisi olla "Ohjelmistotuotteen hallinta"; 4. kurssi on "${elementText}"`);
//            });
            kurssiLinks[2].getText().then((elementText) => {
               assert.ok(elementText.includes("Mobiiliohjelmointi"),
                       `3. kurssi pitäisi olla "Mobiiliohjelmointi"; 3. kurssi on "${elementText}"`);
            });

            kurssiLinks[3].getText().then((elementText) => {
               assert.ok(elementText.includes("Ohjelmistoprojekti"),
                       `4. kurssi pitäisi olla "Ohjelmistoprojekti"; 4. kurssi on "${elementText}"`);
            });

            kurssiLinks[4].getText().then((elementText) => {
               assert.ok(elementText.includes("Ohjelmistotuotteen hallinta"),
                       `5. kurssi pitäisi olla "Ohjelmistotuotteen hallinta"; 5. kurssi on "${elementText}"`);
            });
//

            // lienee mahdollisuus, että tämä suoritetaan, vaikka tämän testin,
            // jokin assert epäonnistuu (rinnakkaisuus/asynkronisuus ...)
            tests_succeeded_so_far = true;

         });

      }); // browser.get

   });// test.it


   // seuraava testi tallettaa tämän myöhempää käyttöä varten
   var mobiiliCuid = null; // Mobiiliohjelmointi-kurssin cuid


   // -------------------------------------------------------------------
   test.it('Kurssit-sivun linkin klikkaus vie oikealle Kurssi-sivulle', () => {
      // ----------------------------------------------------------------

      assert.ok(tests_succeeded_so_far,
              'Testausta jatketaan vain, jos edelliset testit onnistuvat');
      tests_succeeded_so_far = false;

      /*
       * Siirrytään Kurssit -sivulle
       */

      browser.get(`${ServerAddress}/kurssit`).then(() => {

         /*
          * Sivulta löyttyy Kurssi-sivulle osoittava linkki (Mobiiliohjelmointi)
          */

         browser.findElements(By.linkText('Mobiiliohjelmointi')).then(elements => {

            assert.equal(elements.length, 1);

            /*
             * Poimitaan linkistä talteen Mobiiliohjelmointi-kurssin cuid 
             */

            elements[0].getAttribute('href').then((hrefValue) => {
               const match = hrefValue.match(/\/kurssit\/(.+)/);
               assert.ok(match);
               assert.equal(match.length, 2);
               mobiiliCuid = match[1];
            });

            /*
             * Seurataan Mobiiliohjelmointi-linkkiä 
             */

            elements[0].click().then(() => {

               browser.findElement(By.css('h2')).getText().then((h2Text) => {
                  assert.equal(h2Text, 'Kurssi',
                          `Sivulla on otsikko "${h2Text}"; pitäisi olla "Kurssi"`);

               });

               browser.findElement(By.css('body')).getText().then((bodyText) => {
                  assert.ok(bodyText.includes('Mobiiliohjelmointi'),
                          `sivulta (sisältö: "${bodyText}") pitäisi löytyä teksti: "Mobiiliohjelmointi"`);

                  // saattaa olla, että ehditään tänne vaikka jokin aikaisempi 
                  // assert epäonnistuu
                  tests_succeeded_so_far = true;
               });

            });
         });

      });// browser.get
   });// test.it


   // -------------------------------------------------------------------
   test.it('Kurssi-sivulla on odotettu sisältö', () => {
      // ----------------------------------------------------------------

      assert.ok(tests_succeeded_so_far,
              'Testausta jatketaan vain, jos edelliset testit onnistuvat');
      tests_succeeded_so_far = false;

      const ExpectedCourseMark = 'PLA-32820';
      const ExpectedCourseName = 'Mobiiliohjelmointi';
      const ExpectedSize = 'Laajuus: 5';
      const ExpectedInstructor = 'Mikama, Santtu';

      browser.get(`${ServerAddress}/kurssit/${mobiiliCuid}`).then(() => {

         browser.findElement(By.css('body')).getText().then((bodyText) => {

            assert.ok(bodyText.includes(ExpectedCourseMark),
                    `sivulta pitäisi (sisältö: "${bodyText}") pitäisi löytyä teksti: "${ExpectedCourseMark}"`);

            assert.ok(bodyText.includes(ExpectedCourseName),
                    `sivulta pitäisi (sisältö: "${bodyText}") pitäisi löytyä teksti: "${ExpectedCourseName}"`);

            assert.ok(bodyText.includes(ExpectedSize),
                    `sivulta pitäisi (sisältö: "${bodyText}") pitäisi löytyä teksti: "${ExpectedSize}"`);

            assert.ok(bodyText.includes(ExpectedInstructor),
                    `sivulta pitäisi (sisältö: "${bodyText}") pitäisi löytyä teksti: "${ExpectedInstructor}"`);

            tests_succeeded_so_far = true;

         });

      });

   });// test.it


   // -------------------------------------------------------------------
   test.it('Kurssi-sivun linkin klikkaus vie opettaja-sivulle', () => {
      // ----------------------------------------------------------------

      assert.ok(tests_succeeded_so_far,
              'Testausta jatketaan vain, jos edelliset testit onnistuvat');
      tests_succeeded_so_far = false;

      const ExpectedH2Content = 'Opettaja';
      const ExpectedFirstname = 'Santtu';
      const ExpectedLastname = 'Mikama';

      browser.get(`${ServerAddress}/kurssit/${mobiiliCuid}`).then(() => {

         browser.findElement(By.linkText('Mikama, Santtu')).click().then(() => {

            browser.findElement(By.css('h2')).getText().then((h2Text) => {
               assert.equal(h2Text, ExpectedH2Content,
                       `sivun otsikon (h2-elementti) sisältö: "${h2Text}"; odotettu sisältö: "${ExpectedH2Content}"`);
            });

            browser.findElement(By.css('body')).getText().then((bodyText) => {

               assert.ok(bodyText.includes(ExpectedFirstname),
                       `sivulta pitäisi (sisältö: "${bodyText}") pitäisi löytyä teksti: "${ExpectedFirstname}"`);

               assert.ok(bodyText.includes(ExpectedLastname),
                       `sivulta pitäisi (sisältö: "${bodyText}") pitäisi löytyä teksti: "${ExpectedLastname}"`);
            });
         });
      });

   });// test.it


}); // test.describe

