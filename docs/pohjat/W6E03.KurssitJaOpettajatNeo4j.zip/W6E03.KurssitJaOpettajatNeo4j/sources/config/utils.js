

/**
 * 
 * @param {type} records
 * @param {type} pos
 * @returns {Array|arrify.arr|nm$_utils.arrify.arr}
 */
function arrify(records, pos) {
   const i = pos ? pos : 0;
   const arr = [];
   records.forEach((record) => {
      if (record.get(i)) {
         var obj = Object.assign({}, record.get(i).properties);
         obj.key = record.get(i).identity.toString();
         arr.push(obj);
      }
   });
   return arr;
}


module.exports = {
   arrify: arrify
};

