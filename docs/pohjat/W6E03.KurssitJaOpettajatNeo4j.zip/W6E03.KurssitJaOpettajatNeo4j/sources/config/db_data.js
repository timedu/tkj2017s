
// ------------------------------------------------------------------
const opettajat_ja_kurssit = [
// ------------------------------------------------------------------
   {
      "sukunimi": "Veto",
      "etunimi": "Karri",
      "kurssis": [
         {
            "tunnus": "PLA-32602",
            "nimi": "Tiedonhallinta ja tietokannat",
            "laajuus": "4"
         }, {
            "tunnus": "PLA-33416",
            "nimi": "Software Engineering Management",
            "laajuus": "5"
         }, {
            "tunnus": "PLA-33450",
            "nimi": "Ohjelmistotuotteen hallinta",
            "laajuus": "4"
         }, {
            "tunnus": "PLA-33600",
            "nimi": "Ohjelmistoprojekti",
            "laajuus": "5-9"
         }
      ]
   }, {
      "sukunimi": "Jukola",
      "etunimi": "Leevi",
      "kurssis": [
         {
            "tunnus": "PLA-33120",
            "nimi": "Tietojärjestelmän mallintaminen",
            "laajuus": "5"
         }
      ]
   }, {
      "sukunimi": "Rämeenperä",
      "etunimi": "Niilo",
      "kurssis": [
         {
            "tunnus": "PLA-32200",
            "nimi": "Tietorakenteet",
            "laajuus": "6"
         }
      ]
   }, {
      "sukunimi": "Ahtola",
      "etunimi": "Pertti",
      "kurssis": [
         {
            "tunnus": "PLA-33110",
            "nimi": "Käyttäjäkeskeinen suunnittelu",
            "laajuus": "4"
         }
      ]
   }, {
      "sukunimi": "Mikama",
      "etunimi": "Santtu",
      "kurssis": [
         {
            "tunnus": "PLA-31100",
            "nimi": "Ohjelmointitekniikka",
            "laajuus": "6"
         }, {
            "tunnus": "PLA-32100",
            "nimi": "Olio-ohjelmointi",
            "laajuus": "6"
         }, {
            "tunnus": "PLA-32310",
            "nimi": "Sulautetut järjestelmät",
            "laajuus": "6"
         }, {
            "tunnus": "PLA-32820",
            "nimi": "Mobiiliohjelmointi",
            "laajuus": "5"
         }
      ]
   }, {
      "sukunimi": "Käkilä",
      "etunimi": "Simo",
      "kurssis": [
         {
            "tunnus": "PLA-32610",
            "nimi": "Tietokantajärjestelmät",
            "laajuus": "4"
         }, {
            "tunnus": "PLA-32811",
            "nimi": "Web-ohjelmointi",
            "laajuus": "4"
         }, {
            "tunnus": "PLA-32831",
            "nimi": "Web-selainohjelmointi",
            "laajuus": "4"
         }, {
            "tunnus": "PLA-32841",
            "nimi": "Web-palvelinohjelmointi",
            "laajuus": "4"
         }
      ]
   }
];

// ------------------------------------------------------------------
const opettaja_vailla_kursseja = {
// ------------------------------------------------------------------
   "sukunimi": "Simpsonius",
   "etunimi": "Bartholomeus"
};

// ------------------------------------------------------------------
const kurssi_vailla_opettajaa = {
// ------------------------------------------------------------------
   "tunnus": "PLA-33300",
   "nimi": "Johdatus ohjelmistotuotantoon",
   "laajuus": "5"
};

// ------------------------------------------------------------------
const kurssien_esitietovaatimukset = [
// ------------------------------------------------------------------
   {
      kurssi: 'Olio-ohjelmointi',
      esitieto: 'Ohjelmointitekniikka',
      tyyppi: 'p' // pakollinen 
   },
   {
      kurssi: 'Tietorakenteet',
      esitieto: 'Olio-ohjelmointi',
      tyyppi: 'p'
   },
   {
      kurssi: 'Sulautetut järjestelmät',
      esitieto: 'Olio-ohjelmointi',
      tyyppi: 'p'
   },
   {
      kurssi: 'Tietokantajärjestelmät',
      esitieto: 'Olio-ohjelmointi',
      tyyppi: 's' // suoriteltava
   },
   {
      kurssi: 'Tietokantajärjestelmät',
      esitieto: 'Tiedonhallinta ja tietokannat',
      tyyppi: 's'
   },
   {
      kurssi: 'Tietokantajärjestelmät',
      esitieto: 'Web-ohjelmointi',
      tyyppi: 's'
   },
   {
      kurssi: 'Web-ohjelmointi',
      esitieto: 'Ohjelmointitekniikka',
      tyyppi: 'p'
   },
   {
      kurssi: 'Web-ohjelmointi',
      esitieto: 'Olio-ohjelmointi',
      tyyppi: 's'
   },
   {
      kurssi: 'Web-ohjelmointi',
      esitieto: 'Tiedonhallinta ja tietokannat',
      tyyppi: 's'
   },
   {
      kurssi: 'Mobiiliohjelmointi',
      esitieto: 'Olio-ohjelmointi',
      tyyppi: 'p'
   },
   {
      kurssi: 'Web-selainohjelmointi',
      esitieto: 'Olio-ohjelmointi',
      tyyppi: 's'
   },
   {
      kurssi: 'Web-selainohjelmointi',
      esitieto: 'Web-ohjelmointi',
      tyyppi: 's'
   },
   {
      kurssi: 'Web-palvelinohjelmointi',
      esitieto: 'Olio-ohjelmointi',
      tyyppi: 'p'
   },
   {
      kurssi: 'Web-palvelinohjelmointi',
      esitieto: 'Tiedonhallinta ja tietokannat',
      tyyppi: 's'
   },
   {
      kurssi: 'Web-palvelinohjelmointi',
      esitieto: 'Web-ohjelmointi',
      tyyppi: 's'
   },
   {
      kurssi: 'Software Engineering Management',
      esitieto: 'Ohjelmointitekniikka',
      tyyppi: 's'
   },
   {
      kurssi: 'Ohjelmistotuotteen hallinta',
      esitieto: 'Ohjelmointitekniikka',
      tyyppi: 'p'
   },
   {
      kurssi: 'Ohjelmistotuotteen hallinta',
      esitieto: 'Tietojärjestelmän mallintaminen',
      tyyppi: 's'
   },
   {
      kurssi: 'Ohjelmistotuotteen hallinta',
      esitieto: 'Software Engineering Management',
      tyyppi: 's'
   },
   {
      kurssi: 'Ohjelmistoprojekti',
      esitieto: 'Ohjelmointitekniikka',
      tyyppi: 'p'
   },
   {
      kurssi: 'Ohjelmistoprojekti',
      esitieto: 'Olio-ohjelmointi',
      tyyppi: 's'
   },
   {
      kurssi: 'Ohjelmistoprojekti',
      esitieto: 'Tiedonhallinta ja tietokannat',
      tyyppi: 'p'
   },
   {
      kurssi: 'Ohjelmistoprojekti',
      esitieto: 'Web-ohjelmointi',
      tyyppi: 's'
   },
   {
      kurssi: 'Ohjelmistoprojekti',
      esitieto: 'Käyttäjäkeskeinen suunnittelu',
      tyyppi: 's'
   },
   {
      kurssi: 'Ohjelmistoprojekti',
      esitieto: 'Tietojärjestelmän mallintaminen',
      tyyppi: 's'
   },
   {
      kurssi: 'Ohjelmistoprojekti',
      esitieto: 'Software Engineering Management',
      tyyppi: 's'
   },
   {
      kurssi: 'Ohjelmistoprojekti',
      esitieto: 'Ohjelmistotuotteen hallinta',
      tyyppi: 's'
   }
];


