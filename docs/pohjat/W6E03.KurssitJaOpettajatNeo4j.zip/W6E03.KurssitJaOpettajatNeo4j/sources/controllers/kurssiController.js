
/* global Promise */


// TKJ, Tehtävä 6.3

// Nimi: 
// OppNro: 


const arrify = require('../config/utils').arrify;
const db = require('../config/db_connection');


const HaeKaikkiKurssit = "\
   ";

const HaeKurssiJaOpettaja = "\
   ";

const HaeValittomatEsitiedot = "\
   ";

const HaeMuutEsitiedot = "\
   ";

const HaeEsitietoKursseille = "\
   ";


module.exports = (app) => {

   app.get('/', (req, res) => {
      res.redirect('/kurssit');
   });

   app.get('/kurssit', (req, res) => {

       res.send(req.url);
       
       // ...

   });


   app.get('/kurssit/:key', (req, res) => {

       res.send(req.url);

//      const kurssi_key = req.params.key;
//
//      const session = db.session();
//      session.run(HaeKurssiJaOpettaja, {id: kurssi_key}).then((result) => {
//         const kurssi = arrify(result.records)[0];
//         const opettaja = arrify(result.records, 1)[0];
//         kurssi.opettaja = opettaja;
//         Promise.all([
//            session.run(HaeValittomatEsitiedot, {id: kurssi_key}),
//            session.run(HaeMuutEsitiedot, {kt: kurssi.tunnus}),
//            session.run(HaeEsitietoKursseille, {kt: kurssi.tunnus})
//         ]).then(dataArr => {
//            kurssi.valittomat_esitiedot = arrify(dataArr[0].records);
//            var pakollisuus = arrify(dataArr[0].records, 1);
//            kurssi.valittomat_esitiedot.forEach((esitieto, i) => {
//               esitieto.tyyppi = pakollisuus[i].tyyppi;
//            });
//            kurssi.muut_esitiedot = arrify(dataArr[1].records);
//            kurssi.esitieto_kursseille = arrify(dataArr[2].records);
//            pakollisuus = arrify(dataArr[2].records, 1);
//            kurssi.esitieto_kursseille.forEach((esitieto, i) => {
//               esitieto.tyyppi = pakollisuus[i].tyyppi;
//            });
//            res.render('kurssi_detail', {
//               kurssi: kurssi
//            });
//            session.close();
//         }).catch((error) => {
//            console.error(error);
//            res.send(req.url);
//         });
//      }).catch((error) => {
//         console.error(error);
//         res.send(req.url);
//      });
      
   });
   
};

