
// TKJ, Tehtävä 6.3

// Nimi: 
// OppNro: 


const arrify = require('../config/utils').arrify;
const db = require('../config/db_connection');


module.exports = (app) => {

   app.get('/opettajat', (req, res) => {

      const session = db.session();

      session.run("MATCH (o:Opettaja) RETURN o ORDER BY o.sukunimi").then((result) => {

//
// utils-moduulista löytyvä arrify-funktio tekee tämän muunnoksen:
// 
//      const opettajat = [];
//      result.records.forEach((record) => {
//         var opettaja = Object.assign({}, record.get(0).properties);
//         opettaja.key = record.get(0).identity.toString();
//         opettajat.push(opettaja);
//      });
//

         const opettajat = arrify(result.records);

         res.render('opettaja_list', {
            opettajat: opettajat
         });

         session.close();

      }).catch((error) => {
         console.error(error);
         res.send(req.url);
      });      
   });


   app.get('/opettajat/:key', (req, res) => {

      // res.send(req.url);

      const session = db.session();

      session.run("  MATCH (o:Opettaja)                           \
                  WHERE ID(o) = toInt({id})                    \
                  OPTIONAL MATCH (o)-[:OPETTAA]-> (k:Kurssi)   \
                  RETURN o, k                                  \
                  ORDER BY k.nimi", {
         id: req.params.key

      }).then((result) => {

// 
// datan muokkaus näkymää varten ilman arrify-funktiota:
// 
//      const opettaja = Object.assign({}, result.records[0].get(0).properties);
//      opettaja.key = result.records[0].get(0).identity.toString();
//
//      const kurssit = [];
//
//      if (result.records[0].get(1)) {
//         result.records.forEach((record) => {
//            var kurssi = Object.assign({}, record.get(1).properties);
//            kurssi.key = record.get(1).identity.toString();
//            kurssit.push(kurssi);
//         });
//      }
//
//      opettaja.kurssit = kurssit;
//

         const opettaja = arrify(result.records)[0];
         opettaja.kurssit = arrify(result.records, 1);

         res.render('opettaja_detail', {
            opettaja: opettaja
         });

         session.close();

      }).catch((error) => {
         console.error(error);         
         res.send(req.url);
      });      
   });
};






