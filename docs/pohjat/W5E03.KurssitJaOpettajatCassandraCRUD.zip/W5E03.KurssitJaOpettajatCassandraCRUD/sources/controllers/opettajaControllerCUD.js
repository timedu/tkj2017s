

// TKJ, Tehtävä 5.3

// Nimi: 
// OppNro: 


const db = require('../config/db_connection');
const Uuid = require('cassandra-driver').types.Uuid;

module.exports = function (app) {

   /*
    * ----------------------------------------------------------------------
    * CREATE
    * ----------------------------------------------------------------------
    */

   // --
   // Lisäyslomake
   //

   app.get('/opettajat/insert', function (req, res) {

      res.render('opettaja_insert');
   });

   // --
   // Lisäyksessä tarvittavat CQL-komennot
   // 

   const INSERT_opettaja_list = "\
   INSERT INTO opettaja_list (block_id, sukunimi, etunimi, key) \
   VALUES (1, ?, ?, ?)";


   const INSERT_opettajat = "\
   INSERT INTO opettajat (sukunimi, etunimi, key) \
   VALUES (?, ?, ? )";

   // --
   // Lisäyksen toteutus
   //

   app.post('/opettajat/insert', function (req, res) {

      if (req.body._cancel) {
         res.redirect('/opettajat');
         return;
      }

      // --
      // lisäys opettaja_list -tauluun
      // lisäys opettajat -tauluun
      //

      // ...


      res.redirect('/opettajat');

   });


   /*
    * ----------------------------------------------------------------------
    * UPDATE
    * ----------------------------------------------------------------------
    */

   // --
   // Muutoslomake
   //

   app.get('/opettajat/:key/update', function (req, res) {


      // ...

      // huom. data muutoslomakkeelle
      res.render('opettaja_update', {opettaja: {}});

   });

   // --
   // Muutoksessa tarvittavat CQL-komennot
   // 

   const DELETE_opettaja_list = "\
   DELETE FROM opettaja_list \
   WHERE block_id = 1 \
      AND sukunimi = ? \
      AND etunimi = ?  \
      AND key = ? ";

   const UPDATE_opettajat = "\
   UPDATE opettajat \
   SET sukunimi = ?, etunimi = ? \
   WHERE key = ?";

   const UPDATE_kurssit_opettaja = "\
   UPDATE kurssit \
   SET opettaja = {key: ?, sukunimi: ?, etunimi: ?} \
   WHERE key = ?";

   // INSERT_opettaja_list (määritelty edellä)

   // --
   // Muutoksen toteutus
   //

   app.post('/opettajat/update', (req, res) => {

      if (req.body._cancel) {
         res.redirect(`/opettajat/${req.body.key}`);
         return;
      }

      // --
      // muutos opettaja_list -tauluun (poisto & lisäys)
      // muutos opettajat -tauluun
      // muutos kurssit -tauluun (opettajat-taulusta ao. kurssien tunnukset)
      //


      // ...

       res.redirect('/opettajat');

   });


   /*
    * ----------------------------------------------------------------------
    * DELETE
    * ----------------------------------------------------------------------
    */

   // --
   // Poistolomake
   //

   app.get('/opettajat/:key/delete', function (req, res) {

      // ...

      // huom. data poistolomakkeelle
      res.render('opettaja_delete', {opettaja: {}});

   });

   // --
   // Poistossa tarvittavat CQL-komennot
   // 

   const DELETE_opettajat = "\
   DELETE FROM opettajat \
   WHERE  key = ? ";

   const UPDATE_kurssit_opettaja_delete = "\
   UPDATE kurssit \
   SET opettaja = ? \
   WHERE key = ?";

   // DELETE_opettaja_list (edellä)


   // --
   // Poiston toteutus
   //

   app.post('/opettajat/delete', function (req, res) {

      if (req.body._cancel) {
         res.redirect('/opettajat/' + req.body.key);
         return;
      }

      // --
      // poisto opettaja_list -taulusta
      // poisto opettajat -taulusta
      // muutos kurssit -tauluun (opettajat-taulusta kurssien tunnukset)


      // ...

       res.redirect('/opettajat');

   });

};

