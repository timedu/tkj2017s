
console.log('** db_connection **');

const cassandra = require('cassandra-driver');

const IP = 'localhost';
const PORT = '9042';

const USER = 'cassandra';
const PWD = 'cassandra';

const client = new cassandra.Client({
   contactPoints: [`${IP}:${PORT}`],
   authProvider: new cassandra.auth.PlainTextAuthProvider(USER, PWD)
});

client.connect(function (err) {
   if (err)
      return console.error(err);
   console.log('logged to cassandra');
});

module.exports = client;

