
/* global __dirname, Promise */

console.log('** db_create **');

const Uuid = require('cassandra-driver').types.Uuid;
const db = require('./db_connection'); // tietokantayhteys
const opettajat = require('./db_data'); // tietokantaan talletettava data


/*
 * -------------------------------------------------------------------
 * KEYSPACE: tkj_koulu
 */

const CREATE_KEYSPACE = 'CREATE KEYSPACE IF NOT EXISTS tkj_koulu '
        + 'WITH REPLICATION = '
        + "{'class': 'SimpleStrategy', 'replication_factor': 1 }";


/*
 * -------------------------------------------------------------------
 * UTDs: opettaja, kurssi
 */

const CREATE_TYPE_opettaja = '\
CREATE TYPE IF NOT EXISTS opettaja (\
  key uuid, \
  sukunimi text, \
  etunimi text \
)';

const CREATE_TYPE_kurssi = '\
CREATE TYPE IF NOT EXISTS kurssi (\
  nimi text, \
  key uuid \
)';


/*
 * -------------------------------------------------------------------
 * TABLE, INSERT: opettaja_list
 */

const CREATE_TABLE_opettaja_list = '         \
CREATE TABLE IF NOT EXISTS opettaja_list (   \
  block_id int,                              \
  key uuid,                                  \
  sukunimi text,                             \
  etunimi text,                              \
PRIMARY KEY ((block_id), sukunimi, etunimi, key) )';

const INSERT_opettaja_list = "\
INSERT INTO opettaja_list (block_id, sukunimi, etunimi, key) \
VALUES (1, ?, ?, ?)";


/*
 * -------------------------------------------------------------------
 * TABLE, INSERT: opettajat
 */

const CREATE_TABLE_opettajat = '\
CREATE TABLE IF NOT EXISTS opettajat ( \
  key uuid, \
  sukunimi text STATIC, \
  etunimi text STATIC, \
  kurssi frozen<kurssi>, \
PRIMARY KEY ((key), kurssi) )';

const INSERT_opettajat = "\
INSERT INTO opettajat (sukunimi, etunimi, key, kurssi) \
VALUES (?, ?, ?, {nimi: ?, key: ?} )";


/*
 * -------------------------------------------------------------------
 * TABLE, INSERT: kurssi_list
 */

const CREATE_TABLE_kurssi_list = '\
CREATE TABLE IF NOT EXISTS kurssi_list ( \
  block_id int, \
  key uuid, \
  nimi text, \
PRIMARY KEY ((block_id), nimi, key) )';

const INSERT_kurssi_list = "\
INSERT INTO kurssi_list (block_id, nimi, key) \
VALUES (1, ?, ?)";


/*
 * -------------------------------------------------------------------
 * TABLE, INSERT: kurssit
 */

const CREATE_TABLE_kurssit = '\
CREATE TABLE IF NOT EXISTS kurssit ( \
  key uuid, \
  tunnus text, \
  nimi text, \
  laajuus text, \
  opettaja frozen<opettaja>, \
PRIMARY KEY (key) )';

const INSERT_kurssit = "\
INSERT INTO kurssit (tunnus, nimi, laajuus, key, opettaja) \
VALUES (?, ?, ?, ?, {key: ?, sukunimi: ?, etunimi: ?} )";


/*
 * -------------------------------------------------------------------
 * module.exports : initialize database
 */

module.exports = () => {

   db.execute(CREATE_KEYSPACE).then(() => {

      Promise.all([

         // ---
         // nämä pois kommenteista, kun tietokanta rakennetaan uudelleen
         // (ja jäljempänä oleva 'return' kommentteihin)
         //
         db.execute('DROP TABLE IF EXISTS tkj_koulu.opettaja_list'),
         db.execute('DROP TABLE IF EXISTS tkj_koulu.opettajat'),
         db.execute('DROP TABLE IF EXISTS tkj_koulu.kurssi_list'),
         db.execute('DROP TABLE IF EXISTS tkj_koulu.kurssit'),
         //         
         // ---

         db.execute('USE tkj_koulu')

      ]).then(() => {


         // ---
         // tämä kommenteihin, kun tietokanta rakennetaan uudelleen
         // (ja edempänä olevat 'dropit'  pois kommentteista)
         //
//         console.log('using previous data');
//         return;
         //         
         // ---

         Promise.all([

            db.execute(CREATE_TYPE_opettaja),
            db.execute(CREATE_TYPE_kurssi)

         ]).then(() => {

            Promise.all([

               db.execute(CREATE_TABLE_opettaja_list),
               db.execute(CREATE_TABLE_opettajat),
               db.execute(CREATE_TABLE_kurssi_list),
               db.execute(CREATE_TABLE_kurssit)

            ]).then(() => {

               const InsertRows = [];

               opettajat.forEach(opettaja => {

                  const opettaja_key = Uuid.random();

                  InsertRows.push({
                     query: INSERT_opettaja_list,
                     params: [
                        opettaja.sukunimi,
                        opettaja.etunimi,
                        opettaja_key
                     ]});

                  opettaja.kurssis.forEach(kurssi => {

                     const kurssi_key = Uuid.random();

                     InsertRows.push({
                        query: INSERT_kurssi_list,
                        params: [
                           kurssi.nimi,
                           kurssi_key
                        ]});

                     InsertRows.push({
                        query: INSERT_kurssit,
                        params: [
                           kurssi.tunnus,
                           kurssi.nimi,
                           kurssi.laajuus,
                           kurssi_key,
                           opettaja_key,
                           opettaja.sukunimi,
                           opettaja.etunimi
                        ]});

                     InsertRows.push({
                        query: INSERT_opettajat,
                        params: [
                           opettaja.sukunimi,
                           opettaja.etunimi,
                           opettaja_key,
                           kurssi.nimi,
                           kurssi_key
                        ]});

                  });

               });

               db.batch(InsertRows).then(() => {
                  console.log('rows inserted');
               }).catch(err => { // db.batch
                  console.error(err);
               });

            }).catch(err => { // CREATE TABLES //, READ CSV-FILES
               console.error(err);
            });
         }).catch(err => { // CREATE TYPES
            console.error(err);
         });
      }).catch(err => { // USE KEYSPACE
         console.error(err);
      });
   }).catch(err => { // CREATE KEYSPACE
      console.error(err);
   });

}; // module.exports

